// Test the free LinkedIn analysis system
import { createFreeLinkedInService } from './server/free-apis.js';

async function testLinkedInAnalysis() {
  const analyzer = createFreeLinkedInService();
  
  const testUrls = [
    'https://linkedin.com/in/john-smith-software-engineer',
    'https://linkedin.com/in/sarah-johnson-marketing-director',
    'https://linkedin.com/in/michael-chen-data-scientist',
    'https://linkedin.com/in/emily-rodriguez-business-development',
    'https://linkedin.com/in/david-kim-finance-manager'
  ];
  
  console.log('Testing LinkedIn Profile Analysis System\n');
  
  for (const url of testUrls) {
    try {
      const profileData = await analyzer.analyzeLinkedInProfile(url);
      console.log(`URL: ${url}`);
      console.log(`Analyzed Profile:`, {
        name: profileData.name,
        title: profileData.title,
        company: profileData.company,
        industry: profileData.industry,
        location: profileData.location,
        companySize: profileData.companySize
      });
      console.log('---\n');
    } catch (error) {
      console.error(`Error analyzing ${url}:`, error.message);
    }
  }
}

testLinkedInAnalysis();