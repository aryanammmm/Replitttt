// Master QA Test Suite - Comprehensive Coverage
import fetch from 'node-fetch';

const API_BASE = 'http://localhost:5000';

async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function apiRequest(endpoint, options = {}) {
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, options);
    const data = await response.json();
    return {
      success: response.ok,
      status: response.status,
      data: data,
      headers: response.headers
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

// Test Matrix Coverage Implementation
class QATestSuite {
  constructor() {
    this.results = {
      passed: 0,
      failed: 0,
      critical: 0,
      major: 0,
      minor: 0,
      details: []
    };
  }

  log(testId, description, status, severity, details = {}) {
    const result = {
      testId,
      description,
      status,
      severity,
      timestamp: new Date().toISOString(),
      details
    };
    
    this.results.details.push(result);
    
    if (status === 'PASS') {
      this.results.passed++;
      console.log(`✅ ${testId}: ${description}`);
    } else {
      this.results.failed++;
      console.log(`❌ ${testId}: ${description}`);
      if (details.error) {
        console.log(`   Error: ${details.error}`);
      }
    }
    
    this.results[severity.toLowerCase()]++;
  }

  // TC-001: Landing Page Display
  async testLandingPageDisplay() {
    try {
      const response = await fetch(API_BASE);
      const html = await response.text();
      
      const hasHero = html.includes('EmailAI Pro');
      const hasFeatures = html.includes('Features');
      const hasPricing = html.includes('Pricing');
      
      if (hasHero && hasFeatures && hasPricing) {
        this.log('TC-001', 'Landing page displays correctly', 'PASS', 'Major');
      } else {
        this.log('TC-001', 'Landing page missing critical sections', 'FAIL', 'Major', {
          hasHero, hasFeatures, hasPricing
        });
      }
    } catch (error) {
      this.log('TC-001', 'Landing page failed to load', 'FAIL', 'Major', { error: error.message });
    }
  }

  // TC-004: User Registration Flow
  async testUserRegistration() {
    const testEmail = `qa-test-${Date.now()}@example.com`;
    
    try {
      const result = await apiRequest('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: testEmail,
          company: 'QA Test Corp'
        })
      });
      
      if (result.success && result.data.user && result.data.sessionId) {
        this.log('TC-004', 'User registration successful', 'PASS', 'Critical', {
          userId: result.data.user.id,
          sessionId: result.data.sessionId.substring(0, 8) + '...'
        });
        return { user: result.data.user, sessionId: result.data.sessionId };
      } else {
        this.log('TC-004', 'User registration failed', 'FAIL', 'Critical', {
          error: result.error || result.data?.message,
          status: result.status
        });
        return null;
      }
    } catch (error) {
      this.log('TC-004', 'Registration error', 'FAIL', 'Critical', { error: error.message });
      return null;
    }
  }

  // TC-010: Credit Limit Exceeded
  async testCreditLimitExceeded(sessionId) {
    try {
      // First, exhaust user credits by making multiple requests
      let attempts = 0;
      let lastResult = null;
      
      while (attempts < 105) { // Try to exceed 100 credit limit
        lastResult = await apiRequest('/api/emails/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${sessionId}`
          },
          body: JSON.stringify({
            prospectName: `Test User ${attempts}`,
            prospectCompany: 'Test Corp',
            prospectTitle: 'Manager',
            linkedinUrl: 'https://linkedin.com/in/test-user',
            valueProposition: 'Test solution',
            emailType: 'professional'
          })
        });
        
        if (lastResult.status === 403) {
          this.log('TC-010', 'Credit limit properly enforced', 'PASS', 'Critical', {
            attemptsUntilLimit: attempts,
            statusCode: lastResult.status
          });
          return;
        }
        
        attempts++;
        await delay(50); // Brief delay between requests
      }
      
      this.log('TC-010', 'Credit limit not enforced after 105 attempts', 'FAIL', 'Critical', {
        lastStatus: lastResult?.status,
        attempts
      });
      
    } catch (error) {
      this.log('TC-010', 'Credit limit test error', 'FAIL', 'Critical', { error: error.message });
    }
  }

  // TC-013: Successful Email Generation
  async testEmailGeneration(sessionId) {
    try {
      const result = await apiRequest('/api/emails/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionId}`
        },
        body: JSON.stringify({
          prospectName: 'John Smith',
          prospectCompany: 'Tech Solutions Inc',
          prospectTitle: 'Software Engineer',
          linkedinUrl: 'https://linkedin.com/in/john-smith-engineer',
          valueProposition: 'AI tools reducing development time by 40%',
          emailType: 'professional'
        })
      });
      
      if (result.success && result.data.emails && result.data.emails.length >= 3) {
        const emails = result.data.emails;
        const hasValidScores = emails.every(email => 
          email.personalizationScore >= 7 && email.personalizationScore <= 10
        );
        const hasVariations = emails.length === 3;
        const hasProfileData = !!result.data.profileData;
        
        if (hasValidScores && hasVariations && hasProfileData) {
          this.log('TC-013', 'Email generation successful with valid output', 'PASS', 'Critical', {
            emailCount: emails.length,
            avgScore: emails.reduce((sum, e) => sum + e.personalizationScore, 0) / emails.length,
            hasProfileData
          });
        } else {
          this.log('TC-013', 'Email generation incomplete', 'FAIL', 'Critical', {
            hasValidScores, hasVariations, hasProfileData
          });
        }
      } else {
        this.log('TC-013', 'Email generation failed', 'FAIL', 'Critical', {
          error: result.error || result.data?.message,
          status: result.status
        });
      }
    } catch (error) {
      this.log('TC-013', 'Email generation error', 'FAIL', 'Critical', { error: error.message });
    }
  }

  // TC-027: SQL Injection Protection
  async testSQLInjection(sessionId) {
    const maliciousPayloads = [
      "'; DROP TABLE users;--",
      "' OR '1'='1",
      "'; SELECT * FROM users;--",
      "admin'--",
      "' UNION SELECT * FROM users--"
    ];
    
    for (const payload of maliciousPayloads) {
      try {
        const result = await apiRequest('/api/emails/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${sessionId}`
          },
          body: JSON.stringify({
            prospectName: payload,
            prospectCompany: 'Test Corp',
            prospectTitle: 'Manager',
            linkedinUrl: 'https://linkedin.com/in/test',
            valueProposition: 'Test solution',
            emailType: 'professional'
          })
        });
        
        // Check if request was handled safely (either rejected or sanitized)
        if (result.status === 400 || (result.success && result.data.emails)) {
          // Either properly rejected or safely processed
          continue;
        } else if (result.status === 500) {
          this.log('TC-027', `SQL injection possibly successful with payload: ${payload}`, 'FAIL', 'Critical', {
            payload,
            status: result.status
          });
          return;
        }
        
        await delay(100);
      } catch (error) {
        // Network error is acceptable for security test
        continue;
      }
    }
    
    this.log('TC-027', 'SQL injection protection working', 'PASS', 'Critical');
  }

  // TC-028: XSS Protection Test
  async testXSSProtection(sessionId) {
    const xssPayloads = [
      '<script>alert("xss")</script>',
      '<img src="x" onerror="alert(1)">',
      'javascript:alert(1)',
      '<svg onload="alert(1)">',
      '"><script>alert(1)</script>'
    ];
    
    for (const payload of xssPayloads) {
      try {
        const result = await apiRequest('/api/emails/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${sessionId}`
          },
          body: JSON.stringify({
            prospectName: payload,
            prospectCompany: 'Test Corp',
            prospectTitle: 'Manager',
            linkedinUrl: 'https://linkedin.com/in/test',
            valueProposition: 'Test solution',
            emailType: 'professional'
          })
        });
        
        if (result.success && result.data.emails) {
          // Check if the payload was escaped in the output
          const emailContent = result.data.emails[0].emailBody;
          const isEscaped = !emailContent.includes('<script>') && 
                          !emailContent.includes('onerror=') &&
                          !emailContent.includes('javascript:');
          
          if (isEscaped) {
            continue; // Properly escaped
          } else {
            this.log('TC-028', `XSS payload not escaped: ${payload}`, 'FAIL', 'Critical', {
              payload,
              foundInOutput: emailContent.substring(0, 100)
            });
            return;
          }
        }
        
        await delay(100);
      } catch (error) {
        continue;
      }
    }
    
    this.log('TC-028', 'XSS protection working', 'PASS', 'Critical');
  }

  // TC-030: Rate Limiting Test
  async testRateLimiting(sessionId) {
    try {
      const rapidRequests = [];
      const startTime = Date.now();
      
      // Send 20 rapid requests
      for (let i = 0; i < 20; i++) {
        rapidRequests.push(
          apiRequest('/api/emails/generate', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${sessionId}`
            },
            body: JSON.stringify({
              prospectName: `Rapid Test ${i}`,
              prospectCompany: 'Test Corp',
              prospectTitle: 'Manager',
              linkedinUrl: 'https://linkedin.com/in/test',
              valueProposition: 'Test solution',
              emailType: 'professional'
            })
          })
        );
      }
      
      const results = await Promise.all(rapidRequests);
      const endTime = Date.now();
      
      const rateLimitedRequests = results.filter(r => r.status === 429);
      const successfulRequests = results.filter(r => r.success);
      
      if (rateLimitedRequests.length > 0 || successfulRequests.length < 20) {
        this.log('TC-030', 'Rate limiting working', 'PASS', 'Major', {
          totalRequests: 20,
          successful: successfulRequests.length,
          rateLimited: rateLimitedRequests.length,
          timeMs: endTime - startTime
        });
      } else {
        this.log('TC-030', 'Rate limiting not enforced', 'FAIL', 'Major', {
          allRequestsSucceeded: true,
          timeMs: endTime - startTime
        });
      }
    } catch (error) {
      this.log('TC-030', 'Rate limiting test error', 'FAIL', 'Major', { error: error.message });
    }
  }

  // TC-032: Concurrent Email Generation
  async testConcurrentGeneration(sessionId) {
    try {
      const concurrentCount = 10;
      const requests = Array(concurrentCount).fill(null).map((_, i) =>
        apiRequest('/api/emails/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${sessionId}`
          },
          body: JSON.stringify({
            prospectName: `Concurrent User ${i}`,
            prospectCompany: 'Test Corp',
            prospectTitle: 'Manager',
            linkedinUrl: `https://linkedin.com/in/concurrent-user-${i}`,
            valueProposition: 'Concurrent test solution',
            emailType: 'professional'
          })
        })
      );
      
      const startTime = Date.now();
      const results = await Promise.all(requests);
      const endTime = Date.now();
      
      const successful = results.filter(r => r.success).length;
      const avgTime = (endTime - startTime) / concurrentCount;
      
      if (successful >= concurrentCount * 0.8 && avgTime < 10000) { // 80% success rate, under 10s avg
        this.log('TC-032', 'Concurrent generation handling successful', 'PASS', 'Major', {
          concurrent: concurrentCount,
          successful,
          avgTimeMs: avgTime
        });
      } else {
        this.log('TC-032', 'Concurrent generation issues', 'FAIL', 'Major', {
          concurrent: concurrentCount,
          successful,
          avgTimeMs: avgTime
        });
      }
    } catch (error) {
      this.log('TC-032', 'Concurrent generation test error', 'FAIL', 'Major', { error: error.message });
    }
  }

  // Analytics and API Contract Tests
  async testAnalyticsEndpoint(sessionId) {
    try {
      const result = await apiRequest('/api/analytics/dashboard', {
        headers: { 'Authorization': `Bearer ${sessionId}` }
      });
      
      if (result.success && result.data.overview) {
        const requiredFields = ['totalEmails', 'creditsUsed', 'creditsLimit', 'planType'];
        const hasAllFields = requiredFields.every(field => 
          result.data.overview.hasOwnProperty(field)
        );
        
        if (hasAllFields) {
          this.log('TC-017', 'Analytics endpoint returns valid data', 'PASS', 'Major', {
            fields: Object.keys(result.data.overview)
          });
        } else {
          this.log('TC-017', 'Analytics missing required fields', 'FAIL', 'Major', {
            missing: requiredFields.filter(f => !result.data.overview.hasOwnProperty(f))
          });
        }
      } else {
        this.log('TC-017', 'Analytics endpoint failed', 'FAIL', 'Major', {
          error: result.error || result.data?.message,
          status: result.status
        });
      }
    } catch (error) {
      this.log('TC-017', 'Analytics test error', 'FAIL', 'Major', { error: error.message });
    }
  }

  // Authentication Edge Cases
  async testAuthenticationEdgeCases() {
    // Test with invalid session token
    const invalidToken = 'invalid_session_token_12345';
    
    try {
      const result = await apiRequest('/api/emails/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${invalidToken}`
        },
        body: JSON.stringify({
          prospectName: 'Test User',
          prospectCompany: 'Test Corp',
          prospectTitle: 'Manager',
          linkedinUrl: 'https://linkedin.com/in/test',
          valueProposition: 'Test solution',
          emailType: 'professional'
        })
      });
      
      if (result.status === 401) {
        this.log('TC-006', 'Invalid session properly rejected', 'PASS', 'Critical');
      } else {
        this.log('TC-006', 'Invalid session not properly rejected', 'FAIL', 'Critical', {
          status: result.status,
          shouldBe401: true
        });
      }
    } catch (error) {
      this.log('TC-006', 'Auth edge case test error', 'FAIL', 'Critical', { error: error.message });
    }
  }

  // Input Validation Tests
  async testInputValidation(sessionId) {
    const invalidInputs = [
      { prospectName: '', expectError: true, description: 'empty name' },
      { prospectName: 'A'.repeat(500), expectError: true, description: 'name too long' },
      { valueProposition: '', expectError: true, description: 'empty value prop' },
      { linkedinUrl: 'not-a-url', expectError: true, description: 'invalid URL' },
      { emailType: 'invalid-type', expectError: true, description: 'invalid email type' }
    ];
    
    for (const testCase of invalidInputs) {
      try {
        const payload = {
          prospectName: 'Valid Name',
          prospectCompany: 'Valid Corp',
          prospectTitle: 'Manager',
          linkedinUrl: 'https://linkedin.com/in/valid',
          valueProposition: 'Valid proposition',
          emailType: 'professional',
          ...testCase
        };
        
        const result = await apiRequest('/api/emails/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${sessionId}`
          },
          body: JSON.stringify(payload)
        });
        
        if (testCase.expectError && result.status === 400) {
          continue; // Properly rejected
        } else if (!testCase.expectError && result.success) {
          continue; // Properly accepted
        } else {
          this.log('TC-008', `Input validation failed for ${testCase.description}`, 'FAIL', 'Major', {
            testCase: testCase.description,
            expectedError: testCase.expectError,
            gotStatus: result.status
          });
          return;
        }
        
        await delay(100);
      } catch (error) {
        this.log('TC-008', `Input validation test error: ${testCase.description}`, 'FAIL', 'Major', { 
          error: error.message 
        });
        return;
      }
    }
    
    this.log('TC-008', 'Input validation working correctly', 'PASS', 'Major');
  }

  // PayPal Integration Test (Setup only - no actual payment)
  async testPayPalSetup() {
    try {
      const result = await apiRequest('/paypal/setup');
      
      // PayPal setup may fail due to missing credentials in test environment
      if (result.success || result.status === 500) {
        this.log('TC-021', 'PayPal setup endpoint accessible', 'PASS', 'Major', {
          status: result.status,
          note: 'Production credentials required for full test'
        });
      } else {
        this.log('TC-021', 'PayPal setup endpoint failed', 'FAIL', 'Major', {
          status: result.status,
          error: result.error
        });
      }
    } catch (error) {
      this.log('TC-021', 'PayPal setup test error', 'FAIL', 'Major', { error: error.message });
    }
  }

  // Performance Benchmark Test
  async testPerformanceBenchmarks(sessionId) {
    try {
      // Test email generation performance
      const startTime = Date.now();
      
      const result = await apiRequest('/api/emails/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionId}`
        },
        body: JSON.stringify({
          prospectName: 'Performance Test User',
          prospectCompany: 'Benchmark Corp',
          prospectTitle: 'Performance Engineer',
          linkedinUrl: 'https://linkedin.com/in/performance-test',
          valueProposition: 'Performance testing solution',
          emailType: 'professional'
        })
      });
      
      const endTime = Date.now();
      const responseTime = endTime - startTime;
      
      if (result.success && responseTime < 5000) { // Under 5 seconds
        this.log('PERF-001', 'Email generation performance acceptable', 'PASS', 'Major', {
          responseTimeMs: responseTime,
          benchmark: '< 5000ms'
        });
      } else {
        this.log('PERF-001', 'Email generation performance poor', 'FAIL', 'Major', {
          responseTimeMs: responseTime,
          success: result.success
        });
      }
    } catch (error) {
      this.log('PERF-001', 'Performance test error', 'FAIL', 'Major', { error: error.message });
    }
  }

  // Execute Full Test Suite
  async runAllTests() {
    console.log('🚀 Starting Master QA Test Suite\n');
    
    // Wait for server to be ready
    await delay(2000);
    
    // 1. Basic functionality tests
    await this.testLandingPageDisplay();
    
    // 2. Authentication flow
    const authResult = await this.testUserRegistration();
    if (!authResult) {
      console.log('❌ Cannot continue without valid authentication');
      return this.generateReport();
    }
    
    const { sessionId } = authResult;
    
    // 3. Core email generation
    await this.testEmailGeneration(sessionId);
    
    // 4. Security tests
    await this.testAuthenticationEdgeCases();
    await this.testSQLInjection(sessionId);
    await this.testXSSProtection(sessionId);
    
    // 5. Input validation
    await this.testInputValidation(sessionId);
    
    // 6. Performance and load tests
    await this.testPerformanceBenchmarks(sessionId);
    await this.testConcurrentGeneration(sessionId);
    await this.testRateLimiting(sessionId);
    
    // 7. Analytics and reporting
    await this.testAnalyticsEndpoint(sessionId);
    
    // 8. Payment integration
    await this.testPayPalSetup();
    
    // 9. Credit management (run last as it exhausts credits)
    await this.testCreditLimitExceeded(sessionId);
    
    return this.generateReport();
  }

  generateReport() {
    const { passed, failed, critical, major, minor } = this.results;
    const total = passed + failed;
    const passRate = total > 0 ? ((passed / total) * 100).toFixed(1) : 0;
    
    console.log('\n' + '='.repeat(80));
    console.log('📊 MASTER QA TEST RESULTS');
    console.log('='.repeat(80));
    console.log(`Total Tests: ${total}`);
    console.log(`Passed: ${passed}`);
    console.log(`Failed: ${failed}`);
    console.log(`Pass Rate: ${passRate}%`);
    console.log('');
    console.log(`Critical Issues: ${this.results.details.filter(d => d.severity === 'Critical' && d.status === 'FAIL').length}`);
    console.log(`Major Issues: ${this.results.details.filter(d => d.severity === 'Major' && d.status === 'FAIL').length}`);
    console.log(`Minor Issues: ${this.results.details.filter(d => d.severity === 'Minor' && d.status === 'FAIL').length}`);
    
    console.log('\n📋 DETAILED RESULTS:');
    this.results.details.forEach(result => {
      const status = result.status === 'PASS' ? '✅' : '❌';
      console.log(`${status} ${result.testId}: ${result.description} [${result.severity}]`);
      if (result.details && Object.keys(result.details).length > 0) {
        console.log(`   Details: ${JSON.stringify(result.details, null, 2).substring(0, 200)}`);
      }
    });
    
    const criticalFailures = this.results.details.filter(d => 
      d.severity === 'Critical' && d.status === 'FAIL'
    ).length;
    
    console.log('\n🎯 QA SIGN-OFF STATUS:');
    if (criticalFailures === 0 && parseFloat(passRate) >= 90) {
      console.log('✅ READY FOR PRODUCTION');
      console.log('- Zero critical failures');
      console.log('- Pass rate >= 90%');
      console.log('- All security tests passed');
    } else {
      console.log('❌ NOT READY FOR PRODUCTION');
      console.log(`- Critical failures: ${criticalFailures}`);
      console.log(`- Pass rate: ${passRate}% (need >= 90%)`);
      console.log('- Fix critical issues before deployment');
    }
    
    return {
      passRate: parseFloat(passRate),
      criticalFailures,
      readyForProduction: criticalFailures === 0 && parseFloat(passRate) >= 90
    };
  }
}

// Execute Master QA Suite
const qaRunner = new QATestSuite();
qaRunner.runAllTests().then(report => {
  process.exit(report.readyForProduction ? 0 : 1);
}).catch(error => {
  console.error('QA Suite Error:', error);
  process.exit(1);
});