import { 
  users, 
  generatedEmails, 
  usageLogs, 
  emailGenerations,
  usageAnalytics,
  payments,
  type User, 
  type InsertUser, 
  type GeneratedEmail, 
  type InsertGeneratedEmail, 
  type UsageLog, 
  type InsertUsageLog,
  type EmailGeneration,
  type InsertEmailGeneration,
  type UsageAnalytics,
  type InsertUsageAnalytics,
  type Payment,
  type InsertPayment
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Email operations (legacy)
  createGeneratedEmail(email: InsertGeneratedEmail): Promise<GeneratedEmail>;
  getEmailsByUserId(userId: number): Promise<GeneratedEmail[]>;
  
  // Usage log operations (legacy)
  createUsageLog(log: InsertUsageLog): Promise<UsageLog>;
  getUsageLogsByUserId(userId: number): Promise<UsageLog[]>;

  // New enhanced operations
  createEmailGeneration(generation: InsertEmailGeneration): Promise<EmailGeneration>;
  getEmailGenerationsByUserId(userId: number): Promise<EmailGeneration[]>;
  createUsageAnalytics(analytics: InsertUsageAnalytics): Promise<UsageAnalytics>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByUserId(userId: number): Promise<Payment[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async createGeneratedEmail(insertEmail: InsertGeneratedEmail): Promise<GeneratedEmail> {
    const [email] = await db
      .insert(generatedEmails)
      .values(insertEmail)
      .returning();
    return email;
  }

  async getEmailsByUserId(userId: number): Promise<GeneratedEmail[]> {
    return await db
      .select()
      .from(generatedEmails)
      .where(eq(generatedEmails.userId, userId))
      .orderBy(desc(generatedEmails.createdAt));
  }

  async createUsageLog(insertLog: InsertUsageLog): Promise<UsageLog> {
    const [log] = await db
      .insert(usageLogs)
      .values(insertLog)
      .returning();
    return log;
  }

  async getUsageLogsByUserId(userId: number): Promise<UsageLog[]> {
    return await db
      .select()
      .from(usageLogs)
      .where(eq(usageLogs.userId, userId))
      .orderBy(usageLogs.createdAt);
  }

  // New enhanced operations implementations
  async createEmailGeneration(generation: InsertEmailGeneration): Promise<EmailGeneration> {
    const [result] = await db.insert(emailGenerations).values(generation).returning();
    return result;
  }

  async getEmailGenerationsByUserId(userId: number): Promise<EmailGeneration[]> {
    return await db.select().from(emailGenerations)
      .where(eq(emailGenerations.userId, userId))
      .orderBy(desc(emailGenerations.createdAt));
  }

  async createUsageAnalytics(analytics: InsertUsageAnalytics): Promise<UsageAnalytics> {
    const [result] = await db.insert(usageAnalytics).values(analytics).returning();
    return result;
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [result] = await db.insert(payments).values(payment).returning();
    return result;
  }

  async getPaymentsByUserId(userId: number): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(eq(payments.userId, userId))
      .orderBy(desc(payments.createdAt));
  }
}

export const storage = new DatabaseStorage();
