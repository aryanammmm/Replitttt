// Enhanced email personalization without external APIs
// Uses intelligent pattern matching and industry knowledge

interface EmailPersonalizationData {
  name: string;
  company: string;
  title: string;
  industry: string;
  linkedinUrl?: string;
  valueProposition: string;
}

interface PersonalizedEmailResult {
  subject: string;
  body: string;
  type: string;
  score: number;
  personalizationElements: string[];
}

export class EmailPersonalizationEngine {
  
  async generatePersonalizedEmail(
    data: EmailPersonalizationData, 
    emailType: 'professional' | 'conversational' | 'direct'
  ): Promise<PersonalizedEmailResult> {
    
    const personalizationElements = this.analyzePersonalizationOpportunities(data);
    const industryContext = this.getIndustryContext(data.industry);
    const titleContext = this.getTitleContext(data.title);
    
    switch (emailType) {
      case 'professional':
        return this.generateProfessionalEmail(data, personalizationElements, industryContext, titleContext);
      case 'conversational':
        return this.generateConversationalEmail(data, personalizationElements, industryContext, titleContext);
      case 'direct':
        return this.generateDirectEmail(data, personalizationElements, industryContext, titleContext);
      default:
        return this.generateProfessionalEmail(data, personalizationElements, industryContext, titleContext);
    }
  }

  private analyzePersonalizationOpportunities(data: EmailPersonalizationData): string[] {
    const elements: string[] = [];
    
    // Company size inference
    if (this.isLargeCompany(data.company)) {
      elements.push('enterprise_scale');
    } else if (this.isStartup(data.company)) {
      elements.push('startup_agility');
    } else {
      elements.push('growth_focused');
    }
    
    // Title-based personalization
    if (this.isDecisionMaker(data.title)) {
      elements.push('decision_maker');
    } else if (this.isInfluencer(data.title)) {
      elements.push('influencer');
    } else {
      elements.push('practitioner');
    }
    
    // Industry-specific elements
    elements.push(`industry_${data.industry.toLowerCase().replace(/\s+/g, '_')}`);
    
    return elements;
  }

  private getIndustryContext(industry: string): {
    challenges: string[];
    opportunities: string[];
    terminology: string[];
  } {
    const contexts = {
      'Technology': {
        challenges: ['scaling infrastructure', 'technical debt', 'security concerns', 'talent acquisition'],
        opportunities: ['digital transformation', 'automation', 'AI adoption', 'cloud migration'],
        terminology: ['scalability', 'innovation', 'efficiency', 'optimization']
      },
      'Sales': {
        challenges: ['lead qualification', 'pipeline management', 'quota attainment', 'customer retention'],
        opportunities: ['sales enablement', 'process optimization', 'data-driven insights', 'customer success'],
        terminology: ['conversion', 'pipeline', 'revenue growth', 'customer acquisition']
      },
      'Marketing': {
        challenges: ['lead generation', 'brand awareness', 'ROI measurement', 'customer engagement'],
        opportunities: ['digital marketing', 'personalization', 'automation', 'analytics'],
        terminology: ['engagement', 'conversion', 'brand positioning', 'customer journey']
      },
      'Finance': {
        challenges: ['cost management', 'compliance', 'risk assessment', 'reporting accuracy'],
        opportunities: ['process automation', 'financial analytics', 'cost optimization', 'strategic planning'],
        terminology: ['efficiency', 'accuracy', 'compliance', 'strategic value']
      },
      'Healthcare': {
        challenges: ['patient care quality', 'operational efficiency', 'regulatory compliance', 'cost management'],
        opportunities: ['patient experience', 'operational excellence', 'technology adoption', 'quality improvement'],
        terminology: ['patient outcomes', 'operational efficiency', 'quality care', 'innovation']
      }
    };

    return contexts[industry as keyof typeof contexts] || contexts['Technology'];
  }

  private getTitleContext(title: string): {
    responsibilities: string[];
    priorities: string[];
    communication_style: string;
  } {
    const titleLower = title.toLowerCase();
    
    if (titleLower.includes('ceo') || titleLower.includes('president') || titleLower.includes('founder')) {
      return {
        responsibilities: ['strategic vision', 'company growth', 'stakeholder management'],
        priorities: ['revenue growth', 'market expansion', 'competitive advantage'],
        communication_style: 'strategic'
      };
    } else if (titleLower.includes('cto') || titleLower.includes('vp') || titleLower.includes('director')) {
      return {
        responsibilities: ['team leadership', 'strategic planning', 'operational excellence'],
        priorities: ['team efficiency', 'innovation', 'scalability'],
        communication_style: 'executive'
      };
    } else if (titleLower.includes('manager') || titleLower.includes('lead')) {
      return {
        responsibilities: ['team management', 'project delivery', 'process improvement'],
        priorities: ['team productivity', 'project success', 'quality delivery'],
        communication_style: 'managerial'
      };
    } else {
      return {
        responsibilities: ['individual contribution', 'skill development', 'project execution'],
        priorities: ['professional growth', 'skill enhancement', 'project impact'],
        communication_style: 'peer'
      };
    }
  }

  private generateProfessionalEmail(
    data: EmailPersonalizationData,
    elements: string[],
    industryContext: any,
    titleContext: any
  ): PersonalizedEmailResult {
    
    const challenge = industryContext.challenges[0];
    const opportunity = industryContext.opportunities[0];
    const terminology = industryContext.terminology[0];
    
    const subject = `${opportunity} strategy for ${data.company}`;
    const body = `Dear ${data.name},

I hope this message finds you well. As ${data.title} at ${data.company}, I imagine you're focused on ${titleContext.priorities[0]} and addressing challenges like ${challenge}.

${data.valueProposition} has been helping similar ${data.industry.toLowerCase()} organizations achieve significant improvements in ${terminology}. Given your role in ${titleContext.responsibilities[0]}, I believe there's a valuable opportunity to explore how this could support ${data.company}'s strategic objectives.

Would you be available for a brief 15-minute conversation this week to discuss how we might contribute to your ${opportunity} initiatives?

Best regards,
[Your Name]`;

    return {
      subject,
      body,
      type: 'professional',
      score: 8.5,
      personalizationElements: elements
    };
  }

  private generateConversationalEmail(
    data: EmailPersonalizationData,
    elements: string[],
    industryContext: any,
    titleContext: any
  ): PersonalizedEmailResult {
    
    const opportunity = industryContext.opportunities[1] || industryContext.opportunities[0];
    const terminology = industryContext.terminology[1] || industryContext.terminology[0];
    
    const subject = `Quick question about ${data.company}'s ${opportunity}`;
    const body = `Hi ${data.name}!

Hope you're having a great week. I came across ${data.company} and was impressed by your work in ${data.industry}.

I've been helping similar companies with ${data.valueProposition}, and it got me thinking about your approach to ${terminology} at ${data.company}.

Would you be interested in a quick 10-minute chat? I'd love to share some insights that might be valuable for your team's ${opportunity} efforts.

Best,
[Your Name]

P.S. - No sales pitch, just a genuine conversation about what's working in your space.`;

    return {
      subject,
      body,
      type: 'conversational',
      score: 9.0,
      personalizationElements: elements
    };
  }

  private generateDirectEmail(
    data: EmailPersonalizationData,
    elements: string[],
    industryContext: any,
    titleContext: any
  ): PersonalizedEmailResult {
    
    const terminology = industryContext.terminology[0];
    const priority = titleContext.priorities[0];
    
    const subject = `${terminology} improvement for ${data.company}`;
    const body = `${data.name},

${data.valueProposition} is helping ${data.industry.toLowerCase()} companies improve ${terminology} by 30%+.

Given your focus on ${priority} at ${data.company}, this could be relevant.

Interested in a 10-minute overview?

[Your Name]
[Contact Information]`;

    return {
      subject,
      body,
      type: 'direct',
      score: 7.5,
      personalizationElements: elements
    };
  }

  private isLargeCompany(company: string): boolean {
    const largeCompanyIndicators = ['corp', 'corporation', 'enterprises', 'global', 'international', 'inc', 'llc'];
    return largeCompanyIndicators.some(indicator => 
      company.toLowerCase().includes(indicator)
    );
  }

  private isStartup(company: string): boolean {
    const startupIndicators = ['labs', 'studio', 'ventures', 'tech', 'digital', 'ai', 'app'];
    return startupIndicators.some(indicator => 
      company.toLowerCase().includes(indicator)
    );
  }

  private isDecisionMaker(title: string): boolean {
    const decisionMakerTitles = ['ceo', 'cto', 'cfo', 'president', 'founder', 'owner', 'principal'];
    return decisionMakerTitles.some(dmTitle => 
      title.toLowerCase().includes(dmTitle)
    );
  }

  private isInfluencer(title: string): boolean {
    const influencerTitles = ['vp', 'director', 'head', 'manager', 'lead', 'senior'];
    return influencerTitles.some(infTitle => 
      title.toLowerCase().includes(infTitle)
    );
  }
}

export const emailPersonalizationEngine = new EmailPersonalizationEngine();