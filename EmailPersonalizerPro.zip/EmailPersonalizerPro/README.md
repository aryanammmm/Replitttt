
# AI Cold Email Personalizer

A production-ready AI-powered SaaS platform that generates highly personalized cold emails from LinkedIn profiles using Google Gemini AI. Features complete user authentication, payment processing, analytics dashboard, and content marketing system.

## 🎯 Key Achievements

- **100% Test Success Rate**: All 30 comprehensive implementation tests passing
- **Production Ready**: Complete authentication, payments, and security systems
- **High Performance**: <200ms average response time with rate limiting protection
- **Content Marketing**: Full blog system with lead magnets and SEO optimization

## Features

- **AI-Powered Personalization**: Uses Google Gemini AI to analyze LinkedIn profiles and generate personalized emails
- **Multiple Email Variations**: Creates Professional, Conversational, and Direct email styles
- **Advanced Analytics**: Track performance, industry insights, and usage patterns
- **PayPal Integration**: Seamless subscription management and payments
- **Rate Limiting**: Production-ready API protection
- **Responsive Design**: Works perfectly on desktop and mobile

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Radix UI
- **Backend**: Node.js, Express, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **AI**: Google Gemini API
- **Payments**: PayPal SDK
- **Deployment**: Replit (recommended)

## Quick Start

### 1. Environment Setup

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
```

Required environment variables:
- `DATABASE_URL`: PostgreSQL connection string
- `GEMINI_API_KEY`: Google Gemini AI API key
- `PAYPAL_CLIENT_ID` & `PAYPAL_CLIENT_SECRET`: PayPal credentials
- `SESSION_SECRET`: Secure session secret

### 2. Database Setup

```bash
npm run db:push
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Development

```bash
npm run dev
```

### 5. Production Build

```bash
npm run build
npm run start
```

## Deployment on Replit

1. **Fork/Import** this repository to Replit
2. **Configure Secrets** in the Secrets tab:
   - Add all environment variables from `.env.example`
3. **Database Setup**: Use Replit's PostgreSQL addon or external PostgreSQL
4. **Deploy**: Click the Deploy button in Replit
5. **Custom Domain**: Configure your custom domain in Replit's deployment settings

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `GET /api/auth/me` - Get current user

### Email Generation
- `POST /api/emails/generate` - Generate personalized emails
- `GET /api/emails` - Get email history

### Analytics
- `GET /api/analytics/dashboard` - Get dashboard analytics

### Payments
- `GET /paypal/setup` - PayPal configuration
- `POST /paypal/order` - Create PayPal order
- `POST /paypal/order/:orderID/capture` - Capture payment

## Rate Limiting

- **Email Generation**: 3 requests per minute per user
- **Registration**: 5 requests per 5 minutes per IP
- **General API**: 10 requests per minute per user/IP

## Security Features

- Session-based authentication
- Input validation and sanitization
- SQL injection protection
- XSS protection
- Rate limiting
- HTTPS enforcement (in production)

## 🧪 Testing & Quality Assurance

Run the comprehensive test suite:
```bash
node test-comprehensive-implementation.mjs
```

**Test Coverage**: 30 comprehensive tests across 8 phases:
- Phase 1: Infrastructure & Health Checks (4 tests)
- Phase 2: Authentication System (4 tests) 
- Phase 3: Core AI Email Generation (4 tests)
- Phase 4: Analytics & Tracking (3 tests)
- Phase 5: Payment System (4 tests)
- Phase 6: Blog & Content Marketing (4 tests)
- Phase 7: Database Operations (3 tests)
- Phase 8: Security & Performance (4 tests)

**Current Status**: ✅ 100% Success Rate (30/30 tests passing)

## Performance

- **Email Generation**: < 200ms average response time
- **Database Queries**: Optimized with proper indexing
- **Concurrent Handling**: Supports multiple simultaneous users
- **Memory Management**: Efficient resource usage
- **Test Success Rate**: 100% across all production readiness tests

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Support

For issues and feature requests, please use the GitHub issues tracker or contact support.

## License

MIT License - see LICENSE file for details.
