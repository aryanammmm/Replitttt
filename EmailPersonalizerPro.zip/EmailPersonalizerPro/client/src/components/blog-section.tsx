import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, BookOpen, TrendingUp, Users, Zap, Target, ArrowRight, Clock, User } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { blogPosts, getFeaturedPosts } from "@/data/blog-posts";

const blogCategories = [
  {
    id: "getting-started",
    title: "Getting Started with AI Cold Email",
    icon: BookOpen,
    color: "bg-blue-500",
    posts: [
      "The Complete Guide to AI Cold Email: Transform Your Outreach in 2025",
      "How AI Cold Email Tools Can 10x Your Response Rates",
      "AI Cold Email vs Traditional Cold Email: Which Performs Better?",
      "Getting Started with AI Cold Email: A Step-by-Step Guide for Beginners",
      "Why AI Cold Email is the Future of Sales Outreach",
      "The Ultimate AI Cold Email Checklist for Sales Teams",
      "AI Cold Email 101: Everything You Need to Know to Get Started",
      "How to Choose the Best AI Cold Email Software for Your Business",
      "AI Cold Email Best Practices: Lessons from 10,000+ Campaigns",
      "The Science Behind AI Cold Email: Why It Works So Well"
    ]
  },
  {
    id: "tools-software",
    title: "AI Cold Email Tools & Software",
    icon: Zap,
    color: "bg-purple-500",
    posts: [
      "Top 15 AI Cold Email Tools Compared: Features, Pricing & Reviews",
      "HubSpot vs Outreach vs Reply.io: Best AI Cold Email Platforms 2025",
      "Free AI Cold Email Tools That Actually Work (No Credit Card Required)",
      "AI Cold Email Software ROI: Calculate Your Return on Investment",
      "ChatGPT for Cold Email: How to Write Better Outreach Messages",
      "Jasper AI vs Copy.ai for Cold Email: Which Tool Wins?",
      "The Best AI Writing Tools for Cold Email Campaigns",
      "AI Cold Email Chrome Extensions That Save Hours of Work",
      "How to Integrate AI Cold Email Tools with Your CRM",
      "AI Cold Email Automation: Set It and Forget It Strategies",
      "LinkedIn + AI Cold Email: The Perfect Prospecting Combination",
      "AI Cold Email Analytics: Tools to Track Your Success",
      "Open Source AI Cold Email Tools: Free Alternatives That Work",
      "AI Cold Email API Integration: Developer's Complete Guide",
      "The Ultimate AI Cold Email Tool Stack for Sales Teams"
    ]
  },
  {
    id: "writing-copywriting",
    title: "Writing & Copywriting",
    icon: Target,
    color: "bg-green-500",
    posts: [
      "How to Write AI Cold Emails That Get 40%+ Response Rates",
      "AI Cold Email Templates That Convert: 50+ Proven Examples",
      "The Psychology of AI Cold Email: What Makes Recipients Respond",
      "AI Cold Email Subject Lines: 100+ Examples That Get Opened",
      "How to Personalize AI Cold Emails at Scale Without Sounding Robotic",
      "AI Cold Email Copywriting: The Complete Guide to Better Conversions",
      "Cold Email Pain Points: How AI Solves Your Biggest Writing Challenges",
      "A/B Testing AI Cold Email Copy: What We Learned from 50,000 Sends",
      "How to Make AI Cold Emails Sound Human and Authentic",
      "The 5-Step AI Cold Email Formula That Never Fails",
      "AI Cold Email Follow-Up Sequences: Templates and Timing",
      "How to Use AI to Research Prospects for Better Cold Emails",
      "AI Cold Email Tone and Voice: Finding Your Perfect Style",
      "Common AI Cold Email Mistakes That Kill Response Rates",
      "How to Scale Personal Cold Email Writing with AI"
    ]
  },
  {
    id: "industry-specific",
    title: "Industry-Specific AI Cold Email",
    icon: Users,
    color: "bg-orange-500",
    posts: [
      "AI Cold Email for B2B SaaS: Strategies That Actually Work",
      "Real Estate AI Cold Email: Generate More Leads Automatically",
      "AI Cold Email for Recruitment: Find Better Candidates Faster",
      "eCommerce AI Cold Email: Drive More Sales with Smart Outreach",
      "AI Cold Email for Consultants: Land High-Value Clients",
      "Agency AI Cold Email: Scale Your Client Acquisition",
      "AI Cold Email for Startups: Growth Hacking Your Way to Success",
      "Healthcare AI Cold Email: Compliant Outreach Strategies",
      "AI Cold Email for Financial Services: Build Trust at Scale",
      "Manufacturing AI Cold Email: Reach Decision Makers Effectively",
      "AI Cold Email for EdTech: Connect with Schools and Universities",
      "Legal Services AI Cold Email: Ethical Client Acquisition",
      "AI Cold Email for Non-Profits: Fundraising and Volunteer Recruitment",
      "Tech Startup AI Cold Email: Investor and Customer Outreach",
      "AI Cold Email for E-learning: Student and Partner Acquisition"
    ]
  },
  {
    id: "strategy-advanced",
    title: "Strategy & Advanced Techniques",
    icon: TrendingUp,
    color: "bg-red-500",
    posts: [
      "Multi-Channel AI Cold Email: Combining Email, LinkedIn, and Phone",
      "AI Cold Email Segmentation: Target the Right People with the Right Message",
      "How to Use AI for Cold Email List Building and Prospecting",
      "AI Cold Email Deliverability: Avoid the Spam Folder in 2025",
      "Advanced AI Cold Email Personalization: Beyond First Name and Company",
      "AI Cold Email Sequence Optimization: Timing, Frequency, and Content",
      "How to Use AI to Identify the Best Cold Email Prospects",
      "AI Cold Email for Account-Based Marketing: Target Enterprise Accounts",
      "Cold Email Warm-Up: How AI Helps Establish Sender Reputation",
      "AI-Powered Cold Email Split Testing: Optimize Every Element",
      "How to Use AI to Research Cold Email Prospects on Social Media",
      "AI Cold Email Retargeting: Re-engage Non-Responders Intelligently",
      "The Future of AI Cold Email: Trends and Predictions for 2025",
      "AI Cold Email Compliance: GDPR, CAN-SPAM, and Best Practices",
      "How to Build an AI Cold Email System That Runs Itself"
    ]
  },
  {
    id: "results-case-studies",
    title: "Results & Case Studies",
    icon: TrendingUp,
    color: "bg-indigo-500",
    posts: [
      "Case Study: How AI Cold Email Increased Our Sales by 300%",
      "AI Cold Email Results: 30 Days, 1000 Emails, Here's What Happened",
      "Before and After: Traditional vs AI Cold Email Performance Comparison",
      "How One Startup Used AI Cold Email to Reach $1M ARR",
      "AI Cold Email Success Stories: 10 Companies That Got It Right",
      "The ROI of AI Cold Email: Real Numbers from Real Businesses",
      "How AI Cold Email Helped Us Book 50+ Sales Meetings in 30 Days",
      "AI Cold Email Metrics That Matter: Beyond Open and Click Rates",
      "Why Our AI Cold Email Campaigns Outperform Human-Written Ones",
      "AI Cold Email Conversion Rates: Industry Benchmarks and How to Beat Them",
      "How AI Cold Email Reduced Our Sales Cycle by 40%",
      "The Hidden Costs of Manual Cold Email vs AI Cold Email",
      "AI Cold Email Attribution: Tracking Revenue Back to Your Campaigns",
      "How to Calculate the True Cost per Lead for AI Cold Email",
      "AI Cold Email Pipeline: From Prospect to Paying Customer"
    ]
  },
  {
    id: "troubleshooting",
    title: "Troubleshooting & Optimization",
    icon: Target,
    color: "bg-teal-500",
    posts: [
      "Why Your AI Cold Emails Aren't Working (And How to Fix Them)",
      "AI Cold Email Deliverability Issues: Diagnosis and Solutions",
      "How to Improve AI Cold Email Response Rates by 50%",
      "AI Cold Email Spam Filters: How to Avoid Getting Blocked",
      "Low AI Cold Email Open Rates? Here's How to Fix Them Fast",
      "AI Cold Email Unsubscribe Rates: What's Normal and How to Reduce Them",
      "How to Revive Dead AI Cold Email Campaigns",
      "AI Cold Email List Hygiene: Keep Your Database Clean and Effective",
      "Scaling AI Cold Email: How to Send 10,000+ Emails Without Breaking",
      "AI Cold Email Performance Optimization: Advanced Tactics for Experts",
      "How to Audit Your AI Cold Email Campaigns for Better Results",
      "AI Cold Email Burnout: How to Keep Campaigns Fresh and Engaging",
      "Seasonal AI Cold Email Strategies: Timing Your Campaigns Right",
      "AI Cold Email for Different Time Zones: Global Outreach Best Practices",
      "The Complete AI Cold Email Troubleshooting Guide: Fix Any Problem Fast"
    ]
  }
];

export function BlogSection() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const featuredPosts = getFeaturedPosts();

  const filteredBlogPosts = blogPosts.filter(post => {
    if (selectedCategory && post.category.toLowerCase().replace(/\s+/g, '-') !== selectedCategory) return false;
    if (!searchTerm) return true;
    
    return post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
           post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
           post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  const filteredCategories = blogCategories.filter(category => {
    if (selectedCategory && category.id !== selectedCategory) return false;
    if (!searchTerm) return true;
    
    return category.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
           category.posts.some(post => post.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  const filteredPosts = (posts: string[]) => {
    if (!searchTerm) return posts;
    return posts.filter(post => post.toLowerCase().includes(searchTerm.toLowerCase()));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
            AI Cold Email Knowledge Base
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            Discover 100+ expert-curated blog titles covering everything from getting started with AI cold email 
            to advanced optimization techniques. Learn from the best practices and case studies.
          </p>
          
          {/* Search Bar */}
          <div className="max-w-md mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Search blog topics..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-3 w-full border-2 border-gray-200 dark:border-gray-700 rounded-lg focus:border-blue-500 dark:focus:border-blue-400"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className="mb-2"
            >
              All Categories
            </Button>
            {blogCategories.map((category) => {
              const IconComponent = category.icon;
              return (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.id)}
                  className="mb-2"
                >
                  <IconComponent className="w-4 h-4 mr-2" />
                  {category.title}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Featured Posts Section */}
        {featuredPosts.length > 0 && (
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Featured Articles</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {featuredPosts.map((post) => (
                <Card key={post.id} className="shadow-lg border-0 bg-white dark:bg-slate-800 hover:shadow-xl transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="default">{post.category}</Badge>
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <Clock className="w-4 h-4 mr-1" />
                        {post.readTime}
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <User className="w-4 h-4 mr-1" />
                        {post.author} • {post.date}
                      </div>
                      <Link href={`/blog/${post.slug}`}>
                        <Button variant="outline" size="sm">
                          Read More
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Lead Magnet Section */}
        <div className="mb-12">
          <Card className="bg-gradient-to-r from-blue-500 to-purple-600 border-0 text-white">
            <CardContent className="p-8 text-center">
              <h2 className="text-3xl font-bold mb-4">Get 10 AI Cold Email Templates That Generate 8-18% Response Rates</h2>
              <p className="text-xl mb-6 opacity-90">
                Stop wasting hours writing cold emails that get ignored. These AI-powered templates have generated over $2M in revenue for our clients.
              </p>
              <div className="grid md:grid-cols-2 gap-6 mb-6 text-left">
                <div>
                  <h3 className="font-semibold mb-2">What You Get:</h3>
                  <ul className="space-y-1 text-sm opacity-90">
                    <li>✓ 10 proven templates with real response rates</li>
                    <li>✓ Personalization variables that actually work</li>
                    <li>✓ AI research prompts for automation</li>
                    <li>✓ Industry benchmarks and optimization tips</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Template Categories:</h3>
                  <ul className="space-y-1 text-sm opacity-90">
                    <li>• The Insight Opener (12-18% response)</li>
                    <li>• The Mutual Connection (15-22% response)</li>
                    <li>• The Case Study Approach (10-16% response)</li>
                    <li>• The Breakup Email (8-15% response)</li>
                  </ul>
                </div>
              </div>
              <Link href="/">
                <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
                  Download Free Template Pack
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* All Posts Section */}
        {filteredBlogPosts.length > 0 && (
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">All Posts</h2>
            <div className="grid gap-6">
              {filteredBlogPosts.map((post) => (
                <Card key={post.id} className="shadow-lg border-0 bg-white dark:bg-slate-800 hover:shadow-xl transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-wrap items-center gap-2 mb-3">
                      <Badge variant="default">{post.category}</Badge>
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <Clock className="w-4 h-4 mr-1" />
                        {post.readTime}
                      </div>
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <User className="w-4 h-4 mr-1" />
                        {post.author}
                      </div>
                      <span className="text-sm text-gray-500 dark:text-gray-400">{post.date}</span>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                      <Link href={`/blog/${post.slug}`}>
                        {post.title}
                      </Link>
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {post.excerpt}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {post.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <Link href={`/blog/${post.slug}`}>
                      <Button variant="outline">
                        Read Full Article
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Blog Categories */}
        <div className="grid gap-8">
          {filteredCategories.map((category) => {
            const IconComponent = category.icon;
            const categoryPosts = filteredPosts(category.posts);
            
            if (categoryPosts.length === 0) return null;

            return (
              <Card key={category.id} className="shadow-lg border-0 bg-white dark:bg-slate-800">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`p-2 rounded-lg ${category.color}`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white">
                      {category.title}
                    </CardTitle>
                    <Badge variant="secondary" className="ml-auto">
                      {categoryPosts.length} articles
                    </Badge>
                  </div>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    {category.id === "getting-started" && "Essential guides and fundamentals for beginners starting their AI cold email journey."}
                    {category.id === "tools-software" && "Comprehensive reviews and comparisons of the best AI cold email platforms and tools."}
                    {category.id === "writing-copywriting" && "Master the art of writing compelling AI-generated cold emails that convert."}
                    {category.id === "industry-specific" && "Tailored strategies and tactics for different industries and business types."}
                    {category.id === "strategy-advanced" && "Advanced techniques and sophisticated strategies for experienced users."}
                    {category.id === "results-case-studies" && "Real-world examples, success stories, and performance metrics from actual campaigns."}
                    {category.id === "troubleshooting" && "Solutions to common problems and optimization techniques for better results."}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-3">
                    {categoryPosts.map((post, index) => (
                      <div
                        key={index}
                        className="p-4 bg-gray-50 dark:bg-slate-700 rounded-lg border border-gray-200 dark:border-slate-600 hover:border-blue-300 dark:hover:border-blue-500 transition-colors cursor-pointer group"
                      >
                        <h3 className="font-semibold text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                          {post}
                        </h3>
                        <div className="flex items-center justify-between mt-2">
                          <Badge variant="outline" className="text-xs">
                            {category.title.split(' ')[0]}
                          </Badge>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            Coming Soon
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <Card className="bg-gradient-to-r from-blue-500 to-purple-600 border-0 text-white">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold mb-4">Ready to Start Your AI Cold Email Journey?</h2>
              <p className="text-xl mb-6 opacity-90">
                Try our AI-powered cold email generator and see the difference intelligent personalization makes.
              </p>
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-blue-600 hover:bg-gray-100"
              >
                Start Free Trial
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}