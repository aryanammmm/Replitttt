import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getSessionId } from "@/hooks/useAuth";
import { Mail, Copy, Edit, Sparkles, Clock } from "lucide-react";

const emailSchema = z.object({
  prospectName: z.string().min(1, "Prospect name is required"),
  prospectCompany: z.string().optional(),
  prospectTitle: z.string().optional(),
  linkedinUrl: z.string().url("Please enter a valid LinkedIn URL").optional().or(z.literal("")),
  valueProposition: z.string().min(10, "Value proposition must be at least 10 characters"),
  emailType: z.enum(["professional", "conversational", "direct"]).default("professional")
});

type EmailFormData = z.infer<typeof emailSchema>;

interface GeneratedEmail {
  id: number;
  subjectLine: string;
  emailBody: string;
  emailType: string;
  personalizationScore: number;
  prospectName: string;
  prospectCompany: string | null;
  createdAt: string;
}

export function EmailGenerator() {
  const [generatedEmails, setGeneratedEmails] = useState<GeneratedEmail[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { register, handleSubmit, formState: { errors }, setValue, watch } = useForm<EmailFormData>({
    resolver: zodResolver(emailSchema),
    defaultValues: {
      emailType: "professional"
    }
  });

  // Fetch email history
  const { data: emailHistory } = useQuery({
    queryKey: ["/api/emails"],
    queryFn: async () => {
      const sessionId = getSessionId();
      if (!sessionId) throw new Error("Not authenticated");
      
      const response = await fetch("/api/emails", {
        headers: {
          'Authorization': `Bearer ${sessionId}`
        }
      });
      
      if (!response.ok) throw new Error("Failed to fetch emails");
      
      const data = await response.json();
      return data.emails as GeneratedEmail[];
    }
  });

  const generateEmailMutation = useMutation({
    mutationFn: async (data: EmailFormData) => {
      const sessionId = getSessionId();
      if (!sessionId) throw new Error("Not authenticated");
      
      const response = await fetch("/api/emails/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${sessionId}`
        },
        body: JSON.stringify(data)
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to generate emails");
      }
      
      const result = await response.json();
      return result.emails as GeneratedEmail[];
    },
    onSuccess: (emails) => {
      setGeneratedEmails(emails);
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: "Emails Generated!",
        description: `Successfully generated ${emails.length} personalized email variations.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: EmailFormData) => {
    generateEmailMutation.mutate(data);
  };

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${type} copied to clipboard.`,
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Could not copy to clipboard.",
        variant: "destructive",
      });
    }
  };

  const getVariationColor = (type: string) => {
    switch (type) {
      case "professional": return "bg-blue-100 text-blue-800";
      case "conversational": return "bg-green-100 text-green-800";
      case "direct": return "bg-orange-100 text-orange-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      {/* Input Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Mail className="w-5 h-5" />
            <span>Generate Personalized Emails</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <Label htmlFor="linkedinUrl">LinkedIn Profile URL (optional)</Label>
              <Input
                id="linkedinUrl"
                {...register("linkedinUrl")}
                placeholder="https://linkedin.com/in/prospect-name"
                className="mt-1"
              />
              {errors.linkedinUrl && (
                <p className="text-sm text-destructive mt-1">{errors.linkedinUrl.message}</p>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="prospectName">Prospect Name *</Label>
                <Input
                  id="prospectName"
                  {...register("prospectName")}
                  placeholder="John Smith"
                  className="mt-1"
                />
                {errors.prospectName && (
                  <p className="text-sm text-destructive mt-1">{errors.prospectName.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="prospectCompany">Company</Label>
                <Input
                  id="prospectCompany"
                  {...register("prospectCompany")}
                  placeholder="TechCorp Inc."
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="prospectTitle">Job Title</Label>
              <Input
                id="prospectTitle"
                {...register("prospectTitle")}
                placeholder="VP of Sales"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="emailType">Email Style</Label>
              <Select onValueChange={(value) => setValue("emailType", value as any)} defaultValue="professional">
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="conversational">Conversational</SelectItem>
                  <SelectItem value="direct">Direct</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="valueProposition">Your Value Proposition *</Label>
              <Textarea
                id="valueProposition"
                {...register("valueProposition")}
                placeholder="Describe what specific value you can offer this prospect..."
                rows={4}
                className="mt-1"
              />
              {errors.valueProposition && (
                <p className="text-sm text-destructive mt-1">{errors.valueProposition.message}</p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={generateEmailMutation.isPending}
            >
              {generateEmailMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate 3 Email Variations
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Results Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Generated Emails</span>
            {generateEmailMutation.isPending && (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary" />
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {generatedEmails.length === 0 && !generateEmailMutation.isPending ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2">Generate Your First Email</h3>
                <p className="text-muted-foreground max-w-sm mx-auto">
                  Fill out the form with prospect information to generate personalized cold emails.
                </p>
              </div>
            ) : (
              generatedEmails.map((email, index) => (
                <Card key={index} className="border hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <Badge className={getVariationColor(email.emailType)}>
                        {email.emailType.charAt(0).toUpperCase() + email.emailType.slice(1)}
                      </Badge>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">
                          Score: {email.personalizationScore}/10
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(`Subject: ${email.subjectLine}\n\n${email.emailBody}`, "Email")}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <Label className="text-sm font-medium text-muted-foreground">Subject Line</Label>
                        <div className="bg-muted p-3 rounded mt-1 text-sm">
                          {email.subjectLine}
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-sm font-medium text-muted-foreground">Email Body</Label>
                        <div className="bg-muted p-4 rounded mt-1 text-sm whitespace-pre-wrap">
                          {email.emailBody}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2 mt-4">
                      <Button 
                        className="flex-1" 
                        onClick={() => copyToClipboard(`Subject: ${email.subjectLine}\n\n${email.emailBody}`, "Email")}
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copy Email
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Edit className="w-4 h-4 mr-2" />
                        Edit & Customize
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Emails History */}
      {emailHistory && emailHistory.length > 0 && (
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>Recent Generations</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {emailHistory.slice(0, 5).map((email) => (
                  <div key={email.id} className="flex items-center justify-between p-4 bg-muted rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <Mail className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium text-foreground">
                          {email.prospectName} - {email.prospectCompany || "Unknown Company"}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {email.subjectLine}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={getVariationColor(email.emailType)}>
                        {email.emailType}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(`Subject: ${email.subjectLine}\n\n${email.emailBody}`, "Email")}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
