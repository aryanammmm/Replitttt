import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Mail, X } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const [isSignUp, setIsSignUp] = useState(true);
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  
  const { signup, login, isSigningUp, isLoggingIn, signupError, loginError } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSignUp) {
      signup({ email, company }, {
        onSuccess: () => {
          toast({
            title: "Welcome to EmailAI Pro!",
            description: "Your free trial has started. You have 100 credits to use.",
          });
          onClose();
        },
        onError: (error: Error) => {
          toast({
            title: "Signup failed",
            description: error.message,
            variant: "destructive",
          });
        }
      });
    } else {
      login({ email }, {
        onSuccess: () => {
          toast({
            title: "Welcome back!",
            description: "You've been successfully logged in.",
          });
          onClose();
        },
        onError: (error: Error) => {
          toast({
            title: "Login failed", 
            description: error.message,
            variant: "destructive",
          });
        }
      });
    }
  };

  const resetForm = () => {
    setEmail("");
    setCompany("");
  };

  const switchMode = () => {
    setIsSignUp(!isSignUp);
    resetForm();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <Mail className="w-4 h-4 text-white" />
              </div>
              <span>{isSignUp ? "Start Your Free Trial" : "Welcome Back"}</span>
            </DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="text-center text-sm text-muted-foreground">
            {isSignUp 
              ? "Get 100 personalized emails, no credit card required"
              : "Sign in to your EmailAI Pro account"
            }
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                required
                disabled={isSigningUp || isLoggingIn}
              />
            </div>
            
            {isSignUp && (
              <div className="space-y-2">
                <Label htmlFor="company">Company (optional)</Label>
                <Input
                  id="company"
                  type="text"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="Your company name"
                  disabled={isSigningUp}
                />
              </div>
            )}
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSigningUp || isLoggingIn}
            >
              {isSigningUp || isLoggingIn 
                ? "Please wait..." 
                : isSignUp 
                  ? "Start Free Trial" 
                  : "Sign In"
              }
            </Button>
          </form>
          
          <div className="text-center">
            <Button 
              variant="link" 
              onClick={switchMode}
              disabled={isSigningUp || isLoggingIn}
            >
              {isSignUp 
                ? "Already have an account? Sign in" 
                : "Don't have an account? Start free trial"
              }
            </Button>
          </div>
          
          {isSignUp && (
            <div className="text-xs text-muted-foreground text-center">
              By signing up, you agree to our{" "}
              <a href="#" className="text-primary hover:underline">Terms of Service</a>{" "}
              and{" "}
              <a href="#" className="text-primary hover:underline">Privacy Policy</a>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
