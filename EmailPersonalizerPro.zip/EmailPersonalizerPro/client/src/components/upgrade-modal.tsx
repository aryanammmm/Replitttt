import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import PayPalButton from "./PayPalButton";
import { Check, Zap, Users, Crown, X } from "lucide-react";

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function UpgradeModal({ isOpen, onClose }: UpgradeModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  const plans = [
    {
      id: "professional",
      name: "Professional",
      price: "97",
      period: "/month",
      description: "Perfect for individual sales reps",
      icon: <Zap className="w-6 h-6" />,
      features: [
        "500 AI emails per month",
        "3 email variations per prospect",
        "Advanced LinkedIn analysis",
        "Campaign management",
        "Priority email support",
        "Performance analytics"
      ],
      popular: true,
      credits: 500
    },
    {
      id: "enterprise",
      name: "Enterprise",
      price: "197",
      period: "/month",
      description: "For growing sales teams",
      icon: <Crown className="w-6 h-6" />,
      features: [
        "Unlimited AI emails",
        "5 email variations per prospect",
        "AI-powered follow-up sequences",
        "Team collaboration",
        "Advanced analytics & reporting",
        "Dedicated account manager",
        "API access",
        "Custom integrations"
      ],
      popular: false,
      credits: 10000
    }
  ];

  const handlePlanSelect = (planId: string) => {
    setSelectedPlan(planId);
  };

  const handlePaymentSuccess = async () => {
    if (!selectedPlan) return;

    try {
      const response = await fetch("/api/subscriptions/upgrade", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('sessionId')}`
        },
        body: JSON.stringify({ planType: selectedPlan })
      });

      if (response.ok) {
        toast({
          title: "Upgrade Successful!",
          description: `Welcome to ${selectedPlan} plan. Your new credits are now available.`,
        });
        onClose();
        // Refresh page to update user data
        window.location.reload();
      } else {
        throw new Error("Upgrade failed");
      }
    } catch (error) {
      toast({
        title: "Upgrade Failed",
        description: "There was an error upgrading your plan. Please try again.",
        variant: "destructive",
      });
    }
  };

  const selectedPlanData = plans.find(p => p.id === selectedPlan);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl font-bold">
              Upgrade Your Plan
            </DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-muted-foreground">
            Choose the plan that fits your needs and scale your cold email outreach
          </p>
        </DialogHeader>

        {!selectedPlan ? (
          <div className="space-y-6">
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-sm text-muted-foreground mb-2">Current Plan</div>
              <Badge variant="outline" className="text-lg px-4 py-2">
                {user?.planType?.charAt(0).toUpperCase() + user?.planType?.slice(1)} - {user?.creditsUsed}/{user?.creditsLimit} emails used
              </Badge>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {plans.map((plan) => (
                <Card 
                  key={plan.id}
                  className={`relative cursor-pointer hover:shadow-lg transition-all ${
                    plan.popular ? 'border-primary shadow-md' : ''
                  }`}
                  onClick={() => handlePlanSelect(plan.id)}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-gradient-to-r from-primary to-secondary text-white">
                        Most Popular
                      </Badge>
                    </div>
                  )}

                  <CardHeader className="text-center pb-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4 text-primary">
                      {plan.icon}
                    </div>
                    <CardTitle className="text-xl">{plan.name}</CardTitle>
                    <p className="text-muted-foreground text-sm">{plan.description}</p>
                    <div className="mt-4">
                      <span className="text-4xl font-bold text-foreground">${plan.price}</span>
                      <span className="text-muted-foreground">{plan.period}</span>
                    </div>
                  </CardHeader>

                  <CardContent>
                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center text-sm">
                          <Check className="w-4 h-4 text-accent mr-3 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <Button 
                      className={`w-full ${plan.popular ? 'bg-gradient-to-r from-primary to-secondary hover:opacity-90' : ''}`}
                      variant={plan.popular ? "default" : "outline"}
                    >
                      Select {plan.name}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center text-sm text-muted-foreground">
              <p>All plans include:</p>
              <div className="flex justify-center items-center space-x-6 mt-2">
                <span>✓ LinkedIn profile analysis</span>
                <span>✓ AI-powered personalization</span>
                <span>✓ Multiple email variations</span>
                <span>✓ Cancel anytime</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-2">Complete Your Upgrade</h3>
              <p className="text-muted-foreground">
                You're upgrading to <strong>{selectedPlanData?.name}</strong> plan
              </p>
            </div>

            <Card className="border-primary">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                      {selectedPlanData?.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold">{selectedPlanData?.name} Plan</h4>
                      <p className="text-sm text-muted-foreground">{selectedPlanData?.credits} emails/month</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">${selectedPlanData?.price}</div>
                    <div className="text-sm text-muted-foreground">per month</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg">
                    <h5 className="font-medium mb-2">What you'll get:</h5>
                    <ul className="text-sm space-y-1">
                      {selectedPlanData?.features.slice(0, 3).map((feature, idx) => (
                        <li key={idx} className="flex items-center">
                          <Check className="w-4 h-4 text-accent mr-2" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-4 border-t">
                    <PayPalButton
                      amount={selectedPlanData?.price || "97"}
                      currency="USD"
                      intent="subscription"
                    />
                  </div>

                  <div className="flex space-x-3">
                    <Button variant="outline" onClick={() => setSelectedPlan(null)} className="flex-1">
                      Back to Plans
                    </Button>
                    <Button 
                      className="flex-1 bg-gradient-to-r from-primary to-secondary"
                      onClick={handlePaymentSuccess}
                    >
                      Complete Upgrade
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="text-center text-xs text-muted-foreground">
              <p>Secure payment powered by PayPal. Cancel anytime from your account settings.</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}