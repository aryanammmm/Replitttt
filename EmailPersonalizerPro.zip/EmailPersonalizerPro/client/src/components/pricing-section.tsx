import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UpgradeModal } from "./upgrade-modal";
import { Check, Shield, CreditCard, Headphones } from "lucide-react";

interface PricingSectionProps {
  onSelectPlan: () => void;
}

export function PricingSection({ onSelectPlan }: PricingSectionProps) {
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);

  const plans = [
    {
      name: "Starter",
      price: "$97",
      period: "/month",
      description: "Perfect for individual sales reps",
      features: [
        "100 AI emails per month",
        "3 email variations per prospect", 
        "LinkedIn profile analysis",
        "Campaign management",
        "Email support"
      ],
      popular: false
    },
    {
      name: "Professional",
      price: "$197", 
      period: "/month",
      description: "For growing sales teams",
      features: [
        "500 AI emails per month",
        "3 email variations per prospect",
        "Advanced LinkedIn analysis", 
        "Team campaign sharing",
        "Performance analytics",
        "Priority support"
      ],
      popular: true
    },
    {
      name: "Enterprise",
      price: "$497",
      period: "/month", 
      description: "For large sales organizations",
      features: [
        "Unlimited AI emails",
        "5 email variations per prospect",
        "AI-powered follow-up sequences",
        "Team collaboration",
        "Dedicated account manager",
        "API access"
      ],
      popular: false
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Start free, scale as you grow. No hidden fees, cancel anytime.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${plan.popular ? 'border-primary shadow-lg scale-105' : ''}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-primary to-secondary text-white">
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardContent className="p-8">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h3>
                  <p className="text-muted-foreground mb-6">{plan.description}</p>
                  <div className="mb-6">
                    <span className="text-5xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground">{plan.period}</span>
                  </div>
                  
                  <ul className="space-y-4 mb-8 text-left">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center">
                        <Check className="w-5 h-5 text-accent mr-3 flex-shrink-0" />
                        <span className="text-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    className={`w-full ${plan.popular ? 'bg-gradient-to-r from-primary to-secondary hover:opacity-90' : ''}`}
                    variant={plan.popular ? "default" : "outline"}
                    onClick={plan.name === "Starter" ? onSelectPlan : () => setIsUpgradeModalOpen(true)}
                  >
                    {plan.name === "Enterprise" ? "Upgrade to Enterprise" : plan.name === "Professional" ? "Upgrade to Professional" : "Start Free Trial"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">All plans include a 7-day free trial with 100 free emails</p>
          <div className="flex justify-center items-center space-x-6 text-sm text-muted-foreground">
            <div className="flex items-center">
              <Shield className="w-4 h-4 mr-2" />
              <span>SSL Secured</span>
            </div>
            <div className="flex items-center">
              <CreditCard className="w-4 h-4 mr-2" />
              <span>Cancel Anytime</span>
            </div>
            <div className="flex items-center">
              <Headphones className="w-4 h-4 mr-2" />
              <span>24/7 Support</span>
            </div>
          </div>
        </div>
      </div>

      <UpgradeModal 
        isOpen={isUpgradeModalOpen} 
        onClose={() => setIsUpgradeModalOpen(false)} 
      />
    </section>
  );
}
