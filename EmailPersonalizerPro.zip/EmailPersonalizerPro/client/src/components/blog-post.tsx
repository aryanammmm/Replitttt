import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Clock, User, ArrowLeft, Download, Share2 } from "lucide-react";
import { Link } from "wouter";

interface BlogPostProps {
  title: string;
  content: string;
  category: string;
  readTime: string;
  author: string;
  date: string;
  tags: string[];
}

export function BlogPost({ title, content, category, readTime, author, date, tags }: BlogPostProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Navigation */}
      <div className="sticky top-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 z-10">
        <div className="container mx-auto px-4 py-4">
          <Link href="/blog">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Button>
          </Link>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <Badge variant="default">{category}</Badge>
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <Clock className="w-4 h-4 mr-1" />
                {readTime}
              </div>
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <User className="w-4 h-4 mr-1" />
                {author}
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">{date}</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
              {title}
            </h1>
            
            <div className="flex flex-wrap gap-2 mb-6">
              {tags.map((tag, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            </div>
          </div>

          {/* Lead Magnet CTA */}
          <Card className="bg-gradient-to-r from-blue-500 to-purple-600 border-0 text-white mb-8">
            <CardContent className="p-6 text-center">
              <h3 className="text-2xl font-bold mb-3">🎁 Free Bonus: Complete AI Cold Email Template Pack</h3>
              <p className="text-lg mb-4 opacity-90">
                Get all 10 high-converting templates mentioned in this guide, plus personalization scripts and AI research prompts.
              </p>
              <Link href="/">
                <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
                  Download Free Templates (8-18% Response Rates)
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Article Content */}
          <Card className="shadow-lg border-0 bg-white dark:bg-slate-800">
            <CardContent className="p-8">
              <div 
                className="prose prose-lg dark:prose-invert max-w-none
                  prose-headings:text-gray-900 dark:prose-headings:text-white
                  prose-p:text-gray-700 dark:prose-p:text-gray-300
                  prose-strong:text-gray-900 dark:prose-strong:text-white
                  prose-ul:text-gray-700 dark:prose-ul:text-gray-300
                  prose-ol:text-gray-700 dark:prose-ol:text-gray-300
                  prose-blockquote:border-blue-500 prose-blockquote:bg-blue-50 dark:prose-blockquote:bg-blue-900/20
                  prose-code:bg-gray-100 dark:prose-code:bg-gray-800
                  prose-pre:bg-gray-100 dark:prose-pre:bg-gray-800"
                dangerouslySetInnerHTML={{ __html: content }}
              />
            </CardContent>
          </Card>

          {/* Bottom CTA */}
          <Card className="bg-gradient-to-r from-green-500 to-blue-600 border-0 text-white mt-8">
            <CardContent className="p-8 text-center">
              <h3 className="text-3xl font-bold mb-4">Ready to Transform Your Cold Email Results?</h3>
              <p className="text-xl mb-6 opacity-90">
                Join thousands of sales professionals using AI to generate 8-18% response rates and book more qualified meetings.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/">
                  <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
                    Start Free Trial
                  </Button>
                </Link>
                <Link href="/">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                    Download Template Pack
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Related Articles */}
          <div className="mt-12">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Continue Reading</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="shadow-lg border-0 bg-white dark:bg-slate-800 hover:shadow-xl transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">AI Cold Email Tools Comparison 2025</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    Compare the top AI cold email tools and find the perfect solution for your team's needs and budget.
                  </p>
                  <Button variant="outline" size="sm">
                    Read More
                  </Button>
                </CardContent>
              </Card>
              
              <Card className="shadow-lg border-0 bg-white dark:bg-slate-800 hover:shadow-xl transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">Cold Email Deliverability Best Practices</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    Master email deliverability with technical setup guides and expert tips to ensure your messages reach the inbox.
                  </p>
                  <Button variant="outline" size="sm">
                    Read More
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}