import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Users, Mail, Target, Calendar, Award } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface AnalyticsData {
  overview: {
    totalEmails: number;
    last30Days: number;
    creditsUsed: number;
    creditsLimit: number;
    planType: string;
    linkedInAnalyzed: number;
    analysisRate: number;
  };
  industryBreakdown: Record<string, number>;
  emailTypeStats: Record<string, { count: number; avgScore: number }>;
  dailyUsage: Record<string, number>;
  insights: {
    mostActiveDay: string;
    topIndustry: string;
    bestPerformingType: string;
  };
}

export function AnalyticsDashboard() {
  const { data: analytics, isLoading, error } = useQuery<AnalyticsData>({
    queryKey: ['/api/analytics/dashboard'],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-8 bg-muted rounded w-1/2"></div>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error || !analytics) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground">
            Unable to load analytics data. Please try again later.
          </div>
        </CardContent>
      </Card>
    );
  }

  const { overview, industryBreakdown, emailTypeStats, dailyUsage, insights } = analytics;

  // Prepare chart data
  const industryData = Object.entries(industryBreakdown).map(([industry, count]) => ({
    name: industry,
    value: count,
    percentage: Math.round((count / overview.totalEmails) * 100)
  }));

  const emailTypeData = Object.entries(emailTypeStats).map(([type, stats]) => ({
    name: type.charAt(0).toUpperCase() + type.slice(1),
    count: stats.count,
    avgScore: Math.round(stats.avgScore * 10) / 10
  }));

  const dailyUsageData = Object.entries(dailyUsage)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-14) // Last 14 days
    .map(([date, count]) => ({
      date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      emails: count
    }));

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Emails</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.totalEmails}</div>
            <p className="text-xs text-muted-foreground">
              {overview.last30Days} in last 30 days
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profile Analysis</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.analysisRate}%</div>
            <p className="text-xs text-muted-foreground">
              {overview.linkedInAnalyzed} profiles analyzed
            </p>
            <Progress value={overview.analysisRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Credits Used</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.creditsUsed}</div>
            <p className="text-xs text-muted-foreground">
              of {overview.creditsLimit} available
            </p>
            <Progress 
              value={(overview.creditsUsed / overview.creditsLimit) * 100} 
              className="mt-2" 
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Plan</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              <Badge variant={overview.planType === 'trial' ? 'secondary' : 'default'}>
                {overview.planType.charAt(0).toUpperCase() + overview.planType.slice(1)}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {overview.creditsLimit - overview.creditsUsed} credits remaining
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Insights Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Top Industry</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{insights.topIndustry}</div>
            <p className="text-xs text-muted-foreground">
              Most targeted industry segment
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Best Email Type</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold capitalize">{insights.bestPerformingType}</div>
            <p className="text-xs text-muted-foreground">
              Highest average score
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Most Active Day</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{insights.mostActiveDay || 'N/A'}</div>
            <p className="text-xs text-muted-foreground">
              Peak usage pattern
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="usage" className="space-y-4">
        <TabsList>
          <TabsTrigger value="usage">Usage Trends</TabsTrigger>
          <TabsTrigger value="industries">Industries</TabsTrigger>
          <TabsTrigger value="performance">Email Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="usage" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Email Generation</CardTitle>
              <CardDescription>
                Email generation activity over the last 14 days
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dailyUsageData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="emails" fill="#0088FE" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="industries" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Industry Distribution</CardTitle>
              <CardDescription>
                Breakdown of targeted industries
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={industryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name} (${percentage}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {industryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                
                <div className="space-y-2">
                  {industryData.map((industry, index) => (
                    <div key={industry.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span className="text-sm">{industry.name}</span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {industry.value} emails ({industry.percentage}%)
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Email Type Performance</CardTitle>
              <CardDescription>
                Average scores and usage by email type
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={emailTypeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="avgScore" fill="#00C49F" name="Avg Score" />
                  <Bar dataKey="count" fill="#0088FE" name="Count" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}