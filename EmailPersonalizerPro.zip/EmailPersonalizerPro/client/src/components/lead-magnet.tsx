import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Download, CheckCircle, Mail, FileText, Target, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LeadMagnetProps {
  title?: string;
  subtitle?: string;
  variant?: "default" | "blog" | "compact";
}

export function LeadMagnet({ 
  title = "Download Free AI Cold Email Template Pack",
  subtitle = "10 High-Converting Templates That Generate 8-18% Response Rates",
  variant = "default"
}: LeadMagnetProps) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Simulate API call for lead capture
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setIsSubmitted(true);
      toast({
        title: "Success!",
        description: "Your free template pack is being sent to your email.",
      });
      
      // In a real app, this would trigger email delivery
      console.log("Lead captured:", { email, name });
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <Card className="bg-gradient-to-r from-green-500 to-blue-600 border-0 text-white">
        <CardContent className="p-8 text-center">
          <CheckCircle className="w-16 h-16 mx-auto mb-4" />
          <h3 className="text-2xl font-bold mb-3">Template Pack Sent!</h3>
          <p className="text-lg opacity-90 mb-6">
            Check your email for the complete AI Cold Email Template Pack with all 10 high-converting templates.
          </p>
          <div className="bg-white/10 rounded-lg p-4 mb-6">
            <p className="text-sm">
              <strong>What&apos;s in your inbox:</strong><br />
              • 10 proven templates with 8-18% response rates<br />
              • AI research prompts and personalization scripts<br />
              • Industry benchmarks and optimization tips<br />
              • Implementation checklist and A/B testing guide
            </p>
          </div>
          <Button 
            variant="secondary" 
            className="bg-white text-blue-600 hover:bg-gray-100"
            onClick={() => window.location.href = "/"}
          >
            Start Using AI Cold Email Platform
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (variant === "compact") {
    return (
      <Card className="bg-gradient-to-r from-blue-500 to-purple-600 border-0 text-white">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Download className="w-8 h-8 flex-shrink-0" />
            <div className="flex-1">
              <h3 className="font-bold text-lg mb-1">Free Template Pack</h3>
              <p className="text-sm opacity-90">10 AI templates with 8-18% response rates</p>
            </div>
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-white/20 border-white/30 text-white placeholder:text-white/70 w-48"
              />
              <Button 
                type="submit" 
                disabled={isSubmitting}
                variant="secondary"
                className="bg-white text-blue-600 hover:bg-gray-100"
              >
                {isSubmitting ? "Sending..." : "Download"}
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`border-0 ${variant === "blog" ? "bg-gradient-to-r from-indigo-500 to-purple-600" : "bg-gradient-to-r from-blue-500 to-purple-600"} text-white`}>
      <CardHeader className="text-center pb-4">
        <div className="flex justify-center mb-4">
          <div className="bg-white/20 p-3 rounded-full">
            <FileText className="w-8 h-8" />
          </div>
        </div>
        <CardTitle className="text-3xl font-bold mb-2">{title}</CardTitle>
        <p className="text-xl opacity-90">{subtitle}</p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Value Proposition */}
        <div className="grid md:grid-cols-2 gap-6 text-left">
          <div>
            <h4 className="font-semibold mb-3 flex items-center">
              <Target className="w-5 h-5 mr-2" />
              What You Get:
            </h4>
            <ul className="space-y-2 text-sm opacity-90">
              <li>✓ 10 proven templates with real response rates</li>
              <li>✓ AI research prompts for perfect personalization</li>
              <li>✓ Subject line variations that get opened</li>
              <li>✓ Implementation checklist and best practices</li>
              <li>✓ Industry benchmarks and optimization tips</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-3 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2" />
              Template Performance:
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>The Mutual Connection:</span>
                <Badge variant="secondary" className="bg-white/20 text-white">18% response</Badge>
              </div>
              <div className="flex justify-between">
                <span>Social Proof Stack:</span>
                <Badge variant="secondary" className="bg-white/20 text-white">15% response</Badge>
              </div>
              <div className="flex justify-between">
                <span>Industry Insight:</span>
                <Badge variant="secondary" className="bg-white/20 text-white">14% response</Badge>
              </div>
              <div className="flex justify-between">
                <span>Value-First Approach:</span>
                <Badge variant="secondary" className="bg-white/20 text-white">13% response</Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Social Proof */}
        <div className="bg-white/10 rounded-lg p-4">
          <p className="text-sm text-center">
            <strong>&quot;These templates increased our response rate from 2.1% to 14.7% in just 30 days. 
            We&apos;re now booking 3x more qualified meetings while spending 75% less time on outreach.&quot;</strong>
          </p>
          <p className="text-xs text-center mt-2 opacity-75">
            - Sarah Chen, VP Sales at TechFlow Solutions
          </p>
        </div>

        {/* Lead Capture Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name" className="text-white mb-2 block">
                First Name
              </Label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your first name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="bg-white/20 border-white/30 text-white placeholder:text-white/70"
              />
            </div>
            
            <div>
              <Label htmlFor="email" className="text-white mb-2 block">
                Work Email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your work email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-white/20 border-white/30 text-white placeholder:text-white/70"
              />
            </div>
          </div>
          
          <Button 
            type="submit" 
            disabled={isSubmitting}
            size="lg" 
            className="w-full bg-white text-blue-600 hover:bg-gray-100 font-semibold text-lg py-3"
          >
            {isSubmitting ? (
              <>
                <Mail className="w-5 h-5 mr-2 animate-pulse" />
                Sending Templates...
              </>
            ) : (
              <>
                <Download className="w-5 h-5 mr-2" />
                Download Free Template Pack
              </>
            )}
          </Button>
        </form>

        {/* Trust Indicators */}
        <div className="text-center">
          <p className="text-xs opacity-75 mb-2">
            Trusted by 10,000+ sales professionals • No spam, unsubscribe anytime
          </p>
          <div className="flex justify-center items-center gap-4 text-xs opacity-60">
            <span>🔒 100% Secure</span>
            <span>📧 Instant Delivery</span>
            <span>🎯 Proven Results</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}