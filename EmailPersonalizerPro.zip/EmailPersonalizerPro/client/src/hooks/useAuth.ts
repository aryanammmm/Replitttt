import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface User {
  id: number;
  email: string;
  company?: string;
  creditsUsed: number;
  creditsLimit: number;
  planType: string;
}

interface AuthResponse {
  user: User;
  sessionId: string;
}

let sessionId: string | null = localStorage.getItem('sessionId');

export function useAuth() {
  const queryClient = useQueryClient();

  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    enabled: !!sessionId,
    retry: false,
    queryFn: async () => {
      if (!sessionId) return null;
      
      const response = await fetch("/api/auth/me", {
        headers: {
          'Authorization': `Bearer ${sessionId}`
        }
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          localStorage.removeItem('sessionId');
          sessionId = null;
          return null;
        }
        throw new Error('Failed to fetch user');
      }
      
      return response.json();
    }
  });

  const signupMutation = useMutation({
    mutationFn: async (data: { email: string; company?: string }) => {
      const response = await apiRequest('POST', '/api/auth/signup', data);
      return response.json() as Promise<AuthResponse>;
    },
    onSuccess: (data) => {
      sessionId = data.sessionId;
      localStorage.setItem('sessionId', data.sessionId);
      queryClient.setQueryData(["/api/auth/me"], data.user);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    }
  });

  const loginMutation = useMutation({
    mutationFn: async (data: { email: string }) => {
      const response = await apiRequest('POST', '/api/auth/login', data);
      return response.json() as Promise<AuthResponse>;
    },
    onSuccess: (data) => {
      sessionId = data.sessionId;
      localStorage.setItem('sessionId', data.sessionId);
      queryClient.setQueryData(["/api/auth/me"], data.user);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    }
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      if (!sessionId) return;
      
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${sessionId}`
        }
      });
    },
    onSuccess: () => {
      sessionId = null;
      localStorage.removeItem('sessionId');
      queryClient.setQueryData(["/api/auth/me"], null);
      queryClient.clear();
    }
  });

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    signup: signupMutation.mutate,
    login: loginMutation.mutate,
    logout: logoutMutation.mutate,
    isSigningUp: signupMutation.isPending,
    isLoggingIn: loginMutation.isPending,
    signupError: signupMutation.error,
    loginError: loginMutation.error
  };
}

// Helper function to get session ID for API calls
export function getSessionId() {
  return sessionId;
}
