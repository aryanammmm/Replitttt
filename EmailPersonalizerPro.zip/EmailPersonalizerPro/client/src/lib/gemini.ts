// This file contains Google Gemini API configuration and utilities
// The actual API calls are handled server-side for security

export interface EmailVariation {
  subject: string;
  body: string;
  type: 'professional' | 'conversational' | 'direct';
  score: number;
}

export interface EmailGenerationRequest {
  prospectName: string;
  prospectCompany?: string;
  prospectTitle?: string;
  linkedinUrl?: string;
  valueProposition: string;
  emailType: 'professional' | 'conversational' | 'direct';
}

// This is a client-side utility for the API structure
// Actual generation happens server-side with the Gemini API
export const EMAIL_GENERATION_ENDPOINT = '/api/emails/generate';

export const EMAIL_TYPES = {
  professional: {
    name: 'Professional',
    description: 'Formal, business-oriented tone with clear value proposition',
    color: 'blue'
  },
  conversational: {
    name: 'Conversational', 
    description: 'Friendly, approachable tone that builds rapport',
    color: 'green'
  },
  direct: {
    name: 'Direct',
    description: 'Straight to the point with clear call-to-action',
    color: 'orange'
  }
} as const;
