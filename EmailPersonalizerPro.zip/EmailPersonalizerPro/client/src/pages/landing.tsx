import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AuthModal } from "@/components/auth-modal";
import { PricingSection } from "@/components/pricing-section";
import { LeadMagnet } from "@/components/simple-lead-magnet";
import { Mail, Brain, Zap, Target, Clock, Star, Check, ArrowRight, PlayCircle, Users, BookOpen } from "lucide-react";
import { Link } from "wouter";

export default function LandingPage() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const features = [
    {
      icon: <Brain className="w-6 h-6" />,
      title: "AI-Powered Personalization",
      description: "Advanced AI analyzes LinkedIn profiles, recent posts, and company data to create highly personalized emails.",
      benefits: ["Recent activity analysis", "Company intel integration", "Industry-specific messaging"]
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "3 Email Variations",
      description: "Get multiple approaches for each prospect - Professional, Conversational, and Direct styles.",
      benefits: ["Professional tone", "Conversational approach", "Direct & concise style"]
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: "30-Second Generation",
      description: "Lightning-fast email generation saves hours of manual research and writing time.",
      benefits: ["Instant profile analysis", "Real-time generation", "Bulk processing"]
    },
    {
      icon: <Target className="w-6 h-6" />,
      title: "High Conversion Rates",
      description: "Increase response rates by 300% with intelligent personalization that actually works.",
      benefits: ["Proven results", "Response tracking", "Performance analytics"]
    }
  ];

  const testimonials = [
    {
      content: "EmailAI Pro increased my response rate from 8% to 28% in just two weeks. The personalization is incredible - prospects actually think I spent hours researching them.",
      author: "Mike Johnson",
      role: "Senior Sales Rep, TechFlow",
      rating: 5
    },
    {
      content: "This tool saves me 3-4 hours per day on research and writing. My team went from 15 to 45 qualified meetings per month using these AI-generated emails.",
      author: "Lisa Chen", 
      role: "Sales Director, GrowthWorks",
      rating: 5
    },
    {
      content: "The ROI is insane. We're booking 3x more demos and closing 40% more deals. The AI emails feel authentic and prospects actually engage in meaningful conversations.",
      author: "Robert Brown",
      role: "VP Sales, ScaleCorp", 
      rating: 5
    }
  ];

  const stats = [
    { value: "300%", label: "Higher Response Rate" },
    { value: "10,000+", label: "Sales Professionals" },
    { value: "2.5M+", label: "Emails Generated" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-white border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-foreground">EmailAI Pro</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">Features</a>
              <a href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors">Pricing</a>
              <a href="#testimonials" className="text-muted-foreground hover:text-foreground transition-colors">Success Stories</a>
              <Link href="/blog" className="text-muted-foreground hover:text-foreground transition-colors flex items-center">
                <BookOpen className="w-4 h-4 mr-1" />
                Blog
              </Link>
              <Button variant="ghost" onClick={() => setIsAuthModalOpen(true)}>
                Sign In
              </Button>
              <Button onClick={() => setIsAuthModalOpen(true)}>
                Start Free Trial
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-background to-muted py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-6">
                <Badge className="inline-flex items-center bg-accent text-accent-foreground">
                  <Users className="w-4 h-4 mr-2" />
                  300% Higher Response Rates
                </Badge>
                
                <h1 className="text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                  <span className="block">EmailAI Pro</span>
                  Turn LinkedIn Profiles Into 
                  <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent block">
                    Converting Cold Emails
                  </span>
                </h1>
                
                <p className="text-xl text-muted-foreground leading-relaxed">
                  AI analyzes LinkedIn profiles and generates 3 personalized email variations in 30 seconds. 
                  Used by 10,000+ sales professionals to book more meetings.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-primary to-secondary hover:opacity-90"
                  onClick={() => setIsAuthModalOpen(true)}
                >
                  <ArrowRight className="w-5 h-5 mr-2" />
                  Start Free Trial - 100 Emails
                </Button>
                <Button size="lg" variant="outline">
                  <PlayCircle className="w-5 h-5 mr-2" />
                  Watch Demo
                </Button>
              </div>
              
              <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Check className="w-4 h-4 text-accent mr-2" />
                  <span>No credit card required</span>
                </div>
                <div className="flex items-center">
                  <Check className="w-4 h-4 text-accent mr-2" />
                  <span>7-day free trial</span>
                </div>
                <div className="flex items-center">
                  <Check className="w-4 h-4 text-accent mr-2" />
                  <span>Cancel anytime</span>
                </div>
              </div>
            </div>
            
            <div className="lg:pl-8">
              <Card className="shadow-2xl">
                <div className="bg-muted px-6 py-4 border-b">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                    <span className="ml-4 text-sm text-muted-foreground">EmailAI Pro Dashboard</span>
                  </div>
                </div>
                
                <CardContent className="p-6 space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">LinkedIn Profile URL</label>
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="https://linkedin.com/in/johndoe" 
                        className="w-full px-4 py-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent bg-background" 
                      />
                      <Button size="sm" className="absolute right-3 top-2" variant="ghost">
                        <Target className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex items-start space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold">
                        JD
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-foreground">John Doe</h4>
                        <p className="text-sm text-muted-foreground">VP of Sales at TechCorp • 500+ connections</p>
                        <p className="text-xs text-muted-foreground mt-1">San Francisco, CA • SaaS Industry</p>
                      </div>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-gradient-to-r from-primary to-secondary">
                    <Zap className="w-5 h-5 mr-2" />
                    Generate 3 Email Variations
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-muted-foreground mb-8">Trusted by sales teams at leading companies</p>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            <div className="text-2xl font-bold text-muted-foreground">TechCorp</div>
            <div className="text-2xl font-bold text-muted-foreground">SalesForce</div>
            <div className="text-2xl font-bold text-muted-foreground">HubSpot</div>
            <div className="text-2xl font-bold text-muted-foreground">Outreach</div>
            <div className="text-2xl font-bold text-muted-foreground">Gong</div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Features</h2>
            <p className="text-2xl font-semibold text-foreground mb-4">Everything You Need to Scale Cold Outreach</p>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Powered by Google Gemini AI to create hyper-personalized emails that actually get responses.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6 text-primary">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-4">{feature.title}</h3>
                  <p className="text-muted-foreground mb-4">{feature.description}</p>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    {feature.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-center">
                        <Check className="w-4 h-4 text-accent mr-2" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Loved by Sales Professionals Worldwide</h2>
            <p className="text-xl text-muted-foreground">
              See how our AI is transforming cold outreach for thousands of users
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index}>
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="flex text-yellow-400">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-current" />
                      ))}
                    </div>
                  </div>
                  <blockquote className="text-foreground mb-6">"{testimonial.content}"</blockquote>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold">
                      {testimonial.author.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="ml-4">
                      <div className="font-semibold text-foreground">{testimonial.author}</div>
                      <div className="text-muted-foreground text-sm">{testimonial.role}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Lead Magnet Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-slate-900 dark:to-slate-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Get Your Free AI Cold Email Template Pack</h2>
            <p className="text-xl text-muted-foreground">
              10 proven templates that generate 8-18% response rates, used by 10,000+ sales professionals
            </p>
          </div>
          <LeadMagnet />
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Pricing</h2>
        </div>
        <PricingSection onSelectPlan={() => setIsAuthModalOpen(true)} />
      </section>

      {/* Blog Preview Section */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Master AI Cold Email</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Learn proven strategies, get free templates, and stay ahead with the latest AI cold email techniques.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <Badge variant="default" className="mb-3">Getting Started</Badge>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  The Complete Guide to AI Cold Email
                </h3>
                <p className="text-muted-foreground mb-4">
                  Transform your outreach in 2025 with comprehensive AI strategies that increase response rates by 340%.
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">15 min read</span>
                  <Link href="/blog/complete-guide-ai-cold-email-2025">
                    <Button variant="outline" size="sm">
                      Read More
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <Badge variant="default" className="mb-3">Templates & Resources</Badge>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  10 AI Templates (8-18% Response Rates)
                </h3>
                <p className="text-muted-foreground mb-4">
                  Download proven templates with personalization scripts and AI research prompts used by successful sales teams.
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">18 min read</span>
                  <Link href="/blog/ai-cold-email-template-pack-high-converting">
                    <Button variant="outline" size="sm">
                      Get Templates
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <Badge variant="default" className="mb-3">Writing & Copywriting</Badge>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  AI Templates That Convert
                </h3>
                <p className="text-muted-foreground mb-4">
                  Battle-tested examples that have generated millions in revenue with detailed implementation guides.
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">12 min read</span>
                  <Link href="/blog/ai-cold-email-templates-that-convert">
                    <Button variant="outline" size="sm">
                      Read More
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center">
            <Link href="/blog">
              <Button size="lg" variant="outline">
                <BookOpen className="w-5 h-5 mr-2" />
                View All Articles
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to 3x Your Response Rates?
          </h2>
          <p className="text-xl text-primary-foreground/80 mb-8 max-w-3xl mx-auto">
            Join 10,000+ sales professionals who are crushing their targets with AI-powered personalization.
            Start your free trial today - no credit card required.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-white/90"
              onClick={() => setIsAuthModalOpen(true)}
            >
              <ArrowRight className="w-6 h-6 mr-2" />
              Start Free Trial - 100 Emails
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
              Book a Demo
            </Button>
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-6 text-primary-foreground/80 text-sm">
            <div className="flex items-center">
              <Check className="w-4 h-4 mr-2" />
              <span>7-day free trial</span>
            </div>
            <div className="flex items-center">
              <Check className="w-4 h-4 mr-2" />
              <span>No setup fees</span>
            </div>
            <div className="flex items-center">
              <Check className="w-4 h-4 mr-2" />
              <span>Cancel anytime</span>
            </div>
            <div className="flex items-center">
              <Check className="w-4 h-4 mr-2" />
              <span>30-day money-back guarantee</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                  <Mail className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-white">EmailAI Pro</span>
              </div>
              <p className="text-gray-400 mb-6 max-w-sm">
                Transform your cold outreach with AI-powered personalization. 
                Trusted by thousands of sales professionals worldwide.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Integrations</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 EmailAI Pro. All rights reserved.
            </p>
            <p className="text-gray-400 text-sm mt-4 md:mt-0">
              Made with ❤️ for sales professionals
            </p>
          </div>
        </div>
      </footer>

      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </div>
  );
}
