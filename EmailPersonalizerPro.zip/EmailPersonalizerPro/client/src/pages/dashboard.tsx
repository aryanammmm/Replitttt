import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import { EmailGenerator } from "@/components/email-generator";
import { UpgradeModal } from "@/components/upgrade-modal";
import { Mail, LogOut, User, Zap, TrendingUp, Calendar, BarChart3, CreditCard, Activity, BookOpen } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);

  if (!user) {
    return null;
  }

  const usagePercentage = (user.creditsUsed / user.creditsLimit) * 100;

  const stats = [
    {
      title: "Emails Generated",
      value: user.creditsUsed.toString(),
      icon: <Mail className="w-4 h-4" />,
      trend: "+12 this week"
    },
    {
      title: "Response Rate",
      value: "18.5%", 
      icon: <TrendingUp className="w-4 h-4" />,
      trend: "+3.2% vs industry"
    },
    {
      title: "Meetings Booked",
      value: "12",
      icon: <Calendar className="w-4 h-4" />,
      trend: "+5 this month"
    },
    {
      title: "Time Saved",
      value: "8.2h",
      icon: <BarChart3 className="w-4 h-4" />,
      trend: "this week"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-foreground">EmailAI Pro</span>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Credits Display */}
              <Card className="bg-muted">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-medium text-foreground">
                      {user.creditsUsed} / {user.creditsLimit} emails
                    </span>
                  </div>
                  <Progress value={usagePercentage} className="mt-2 h-2" />
                  {user.planType === "trial" && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-2 w-full text-xs"
                      onClick={() => setIsUpgradeModalOpen(true)}
                    >
                      <CreditCard className="w-3 h-3 mr-1" />
                      Upgrade Plan
                    </Button>
                  )}
                </CardContent>
              </Card>
              
              {/* Navigation */}
              <div className="flex items-center space-x-2">
                <Link href="/analytics">
                  <Button variant="ghost" size="sm">
                    <Activity className="w-4 h-4 mr-2" />
                    Analytics
                  </Button>
                </Link>
                <Link href="/blog">
                  <Button variant="ghost" size="sm">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Blog
                  </Button>
                </Link>
              </div>

              {/* User Menu */}
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <div className="text-sm font-medium text-foreground">{user.email}</div>
                  <div className="text-xs text-muted-foreground capitalize">{user.planType} Plan</div>
                </div>
                <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-muted-foreground" />
                </div>
                <Button variant="ghost" size="sm" onClick={() => logout()}>
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground mb-2">Welcome back, {user.email.split('@')[0]}!</h1>
          <p className="text-muted-foreground">Generate personalized cold emails with AI-powered insights</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.trend}</p>
                  </div>
                  <div className="text-muted-foreground">
                    {stat.icon}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Email Generator */}
        <EmailGenerator />

        {/* Usage Warning */}
        {usagePercentage > 80 && (
          <Card className="mt-8 border-yellow-200 bg-yellow-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-yellow-600" />
                  <div>
                    <h3 className="font-semibold text-yellow-800">Credit Limit Approaching</h3>
                    <p className="text-yellow-700 text-sm">
                      You've used {user.creditsUsed} of {user.creditsLimit} emails. 
                      Upgrade your plan to continue generating personalized emails.
                    </p>
                  </div>
                </div>
                <Button 
                  onClick={() => setIsUpgradeModalOpen(true)}
                  className="bg-yellow-600 hover:bg-yellow-700 text-white"
                >
                  Upgrade Now
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <UpgradeModal 
        isOpen={isUpgradeModalOpen} 
        onClose={() => setIsUpgradeModalOpen(false)} 
      />
    </div>
  );
}
