import { BlogSection } from "@/components/blog-section";

export default function Blog() {
  return <BlogSection />;
}