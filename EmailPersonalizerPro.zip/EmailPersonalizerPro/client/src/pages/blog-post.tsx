import { BlogPost } from "@/components/blog-post";
import { getBlogPost } from "@/data/blog-posts";
import { useRoute } from "wouter";
import NotFound from "./not-found";

export default function BlogPostPage() {
  const [, params] = useRoute("/blog/:slug");
  
  if (!params?.slug) {
    return <NotFound />;
  }

  const post = getBlogPost(params.slug);

  if (!post) {
    return <NotFound />;
  }

  return (
    <BlogPost
      title={post.title}
      content={post.content}
      category={post.category}
      readTime={post.readTime}
      author={post.author}
      date={post.date}
      tags={post.tags}
    />
  );
}