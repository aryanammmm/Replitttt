
// Comprehensive Debug and Test Suite for AI Cold Email Personalizer
import fetch from 'node-fetch';
import { spawn } from 'child_process';

const API_BASE = 'http://localhost:5000';
const TEST_TIMEOUT = 30000; // 30 seconds

class DebugTestSuite {
  constructor() {
    this.results = {
      passed: 0,
      failed: 0,
      warnings: 0,
      errors: [],
      performance: {},
      security: {},
      functionality: {}
    };
    this.sessionId = null;
    this.testUser = null;
  }

  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async apiRequest(endpoint, options = {}) {
    const startTime = Date.now();
    try {
      const response = await fetch(`${API_BASE}${endpoint}`, {
        timeout: TEST_TIMEOUT,
        ...options
      });
      
      let data;
      try {
        data = await response.json();
      } catch (e) {
        data = await response.text();
      }
      
      return {
        success: response.ok,
        status: response.status,
        data: data,
        responseTime: Date.now() - startTime,
        headers: Object.fromEntries(response.headers.entries())
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        responseTime: Date.now() - startTime
      };
    }
  }

  log(testId, description, status, details = {}) {
    const timestamp = new Date().toISOString();
    const result = { testId, description, status, timestamp, details };
    
    if (status === 'PASS') {
      this.results.passed++;
      console.log(`✅ ${testId}: ${description}`);
    } else if (status === 'FAIL') {
      this.results.failed++;
      this.results.errors.push(result);
      console.log(`❌ ${testId}: ${description}`);
      if (details.error) console.log(`   Error: ${details.error}`);
    } else if (status === 'WARN') {
      this.results.warnings++;
      console.log(`⚠️  ${testId}: ${description}`);
    }
    
    if (details.responseTime) {
      console.log(`   Response Time: ${details.responseTime}ms`);
    }
  }

  // Test 1: System Health Check
  async testSystemHealth() {
    console.log('\n🏥 === SYSTEM HEALTH CHECK ===');
    
    // Check server is responding
    const healthCheck = await this.apiRequest('/');
    if (healthCheck.success || healthCheck.status === 200) {
      this.log('HEALTH-001', 'Server is responding', 'PASS', {
        responseTime: healthCheck.responseTime
      });
      this.results.performance.serverResponse = healthCheck.responseTime;
    } else {
      this.log('HEALTH-001', 'Server not responding', 'FAIL', {
        error: healthCheck.error,
        status: healthCheck.status
      });
      return false;
    }

    // Check API endpoints are accessible
    const apiHealth = await this.apiRequest('/api/health');
    if (apiHealth.success) {
      this.log('HEALTH-002', 'API endpoints accessible', 'PASS');
    } else {
      this.log('HEALTH-002', 'API endpoints not accessible', 'WARN', {
        note: 'Health endpoint may not exist, continuing tests'
      });
    }

    return true;
  }

  // Test 2: Authentication Flow Debug
  async testAuthenticationFlow() {
    console.log('\n🔐 === AUTHENTICATION FLOW DEBUG ===');
    
    const testEmail = `debug-test-${Date.now()}@example.com`;
    
    // Test user registration
    const registerResult = await this.apiRequest('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testEmail,
        company: 'Debug Test Corp'
      })
    });

    if (registerResult.success && registerResult.data.sessionId) {
      this.sessionId = registerResult.data.sessionId;
      this.testUser = registerResult.data.user;
      this.log('AUTH-001', 'User registration successful', 'PASS', {
        userId: this.testUser.id,
        email: this.testUser.email,
        responseTime: registerResult.responseTime
      });
    } else {
      this.log('AUTH-001', 'User registration failed', 'FAIL', {
        error: registerResult.error || registerResult.data?.message,
        status: registerResult.status
      });
      return false;
    }

    // Test session validation
    const sessionTest = await this.apiRequest('/api/auth/me', {
      headers: { 'Authorization': `Bearer ${this.sessionId}` }
    });

    if (sessionTest.success) {
      this.log('AUTH-002', 'Session validation working', 'PASS', {
        responseTime: sessionTest.responseTime
      });
    } else {
      this.log('AUTH-002', 'Session validation failed', 'FAIL', {
        status: sessionTest.status,
        error: sessionTest.error
      });
    }

    return true;
  }

  // Test 3: Email Generation System Debug
  async testEmailGeneration() {
    console.log('\n📧 === EMAIL GENERATION SYSTEM DEBUG ===');
    
    if (!this.sessionId) {
      this.log('EMAIL-001', 'No valid session for email testing', 'FAIL');
      return false;
    }

    const testCases = [
      {
        name: 'Valid LinkedIn Profile',
        data: {
          prospectName: 'John Smith',
          prospectCompany: 'Tech Solutions Inc',
          prospectTitle: 'Software Engineer',
          linkedinUrl: 'https://linkedin.com/in/john-smith-engineer',
          valueProposition: 'AI tools that reduce development time by 40%',
          emailType: 'professional'
        }
      },
      {
        name: 'Invalid LinkedIn URL',
        data: {
          prospectName: 'Jane Doe',
          prospectCompany: 'Marketing Corp',
          prospectTitle: 'Marketing Director',
          linkedinUrl: 'not-a-valid-url',
          valueProposition: 'Marketing automation solution',
          emailType: 'conversational'
        }
      },
      {
        name: 'Empty Fields Test',
        data: {
          prospectName: '',
          prospectCompany: '',
          prospectTitle: '',
          linkedinUrl: '',
          valueProposition: '',
          emailType: 'direct'
        }
      }
    ];

    for (const [index, testCase] of testCases.entries()) {
      console.log(`\nTesting: ${testCase.name}`);
      
      const result = await this.apiRequest('/api/emails/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.sessionId}`
        },
        body: JSON.stringify(testCase.data)
      });

      if (result.success && result.data.emails) {
        this.log(`EMAIL-${String(index + 1).padStart(3, '0')}`, 
          `${testCase.name} - Generation successful`, 'PASS', {
          emailCount: result.data.emails.length,
          avgScore: result.data.emails.reduce((sum, e) => sum + e.personalizationScore, 0) / result.data.emails.length,
          responseTime: result.responseTime,
          creditsUsed: result.data.creditsUsed
        });

        // Validate email quality
        for (const email of result.data.emails) {
          if (!email.subjectLine || email.subjectLine.length < 5) {
            this.log(`EMAIL-${String(index + 1).padStart(3, '0')}-Q1`, 
              `${testCase.name} - Invalid subject line`, 'WARN', {
              emailType: email.emailType,
              subjectLength: email.subjectLine?.length || 0
            });
          }
          
          if (email.personalizationScore < 7) {
            this.log(`EMAIL-${String(index + 1).padStart(3, '0')}-Q2`, 
              `${testCase.name} - Low personalization score`, 'WARN', {
              emailType: email.emailType,
              score: email.personalizationScore
            });
          }
        }
      } else {
        const isExpectedFailure = testCase.name === 'Empty Fields Test';
        this.log(`EMAIL-${String(index + 1).padStart(3, '0')}`, 
          `${testCase.name} - ${isExpectedFailure ? 'Expected validation failure' : 'Generation failed'}`, 
          isExpectedFailure ? 'PASS' : 'FAIL', {
          status: result.status,
          error: result.error || result.data?.message,
          responseTime: result.responseTime
        });
      }

      await this.delay(500); // Prevent rate limiting
    }

    return true;
  }

  // Test 4: PayPal Integration Debug
  async testPayPalIntegration() {
    console.log('\n💳 === PAYPAL INTEGRATION DEBUG ===');
    
    // Test PayPal setup endpoint
    const setupResult = await this.apiRequest('/paypal/setup');
    
    if (setupResult.success) {
      this.log('PAYPAL-001', 'PayPal setup endpoint accessible', 'PASS', {
        responseTime: setupResult.responseTime
      });
    } else if (setupResult.status === 401) {
      this.log('PAYPAL-001', 'PayPal credentials issue (expected in development)', 'WARN', {
        status: setupResult.status,
        note: 'This is expected without production PayPal credentials'
      });
    } else {
      this.log('PAYPAL-001', 'PayPal setup endpoint failed', 'FAIL', {
        status: setupResult.status,
        error: setupResult.error
      });
    }

    // Test subscription endpoint (should require auth)
    if (this.sessionId) {
      const subscriptionResult = await this.apiRequest('/api/subscriptions/upgrade', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.sessionId}`
        },
        body: JSON.stringify({
          planType: 'professional'
        })
      });

      if (subscriptionResult.status === 401 || subscriptionResult.status === 500) {
        this.log('PAYPAL-002', 'Subscription endpoint protected (expected behavior)', 'PASS', {
          status: subscriptionResult.status,
          note: 'Endpoint requires PayPal setup'
        });
      } else {
        this.log('PAYPAL-002', 'Unexpected subscription response', 'WARN', {
          status: subscriptionResult.status
        });
      }
    }

    return true;
  }

  // Test 5: Analytics System Debug
  async testAnalyticsSystem() {
    console.log('\n📊 === ANALYTICS SYSTEM DEBUG ===');
    
    if (!this.sessionId) {
      this.log('ANALYTICS-001', 'No valid session for analytics testing', 'FAIL');
      return false;
    }

    const analyticsResult = await this.apiRequest('/api/analytics/dashboard', {
      headers: { 'Authorization': `Bearer ${this.sessionId}` }
    });

    if (analyticsResult.success) {
      const analytics = analyticsResult.data;
      
      this.log('ANALYTICS-001', 'Analytics endpoint accessible', 'PASS', {
        responseTime: analyticsResult.responseTime
      });

      // Validate analytics structure
      const requiredFields = ['overview', 'industryBreakdown', 'emailTypeStats', 'dailyUsage'];
      let missingFields = [];
      
      for (const field of requiredFields) {
        if (!analytics[field]) {
          missingFields.push(field);
        }
      }

      if (missingFields.length === 0) {
        this.log('ANALYTICS-002', 'Analytics data structure valid', 'PASS', {
          totalEmails: analytics.overview?.totalEmails,
          creditsUsed: analytics.overview?.creditsUsed
        });
      } else {
        this.log('ANALYTICS-002', 'Analytics data structure incomplete', 'WARN', {
          missingFields: missingFields
        });
      }
    } else {
      this.log('ANALYTICS-001', 'Analytics endpoint failed', 'FAIL', {
        status: analyticsResult.status,
        error: analyticsResult.error
      });
    }

    return true;
  }

  // Test 6: Performance Benchmarks
  async testPerformance() {
    console.log('\n⚡ === PERFORMANCE BENCHMARKS ===');
    
    if (!this.sessionId) {
      this.log('PERF-001', 'No valid session for performance testing', 'FAIL');
      return false;
    }

    // Test concurrent email generation
    const concurrentRequests = 5;
    const startTime = Date.now();
    
    const requests = Array(concurrentRequests).fill(null).map((_, i) =>
      this.apiRequest('/api/emails/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.sessionId}`
        },
        body: JSON.stringify({
          prospectName: `Performance User ${i + 1}`,
          prospectCompany: 'Performance Corp',
          prospectTitle: 'Performance Manager',
          linkedinUrl: `https://linkedin.com/in/performance-user-${i + 1}`,
          valueProposition: 'Performance testing solution',
          emailType: 'professional'
        })
      })
    );

    const results = await Promise.all(requests);
    const totalTime = Date.now() - startTime;
    const successfulRequests = results.filter(r => r.success).length;
    const avgResponseTime = results.reduce((sum, r) => sum + (r.responseTime || 0), 0) / results.length;

    if (successfulRequests >= Math.floor(concurrentRequests * 0.8)) {
      this.log('PERF-001', 'Concurrent request handling acceptable', 'PASS', {
        concurrent: concurrentRequests,
        successful: successfulRequests,
        totalTime: totalTime,
        avgResponseTime: Math.round(avgResponseTime)
      });
    } else {
      this.log('PERF-001', 'Concurrent request handling poor', 'FAIL', {
        concurrent: concurrentRequests,
        successful: successfulRequests,
        totalTime: totalTime
      });
    }

    this.results.performance.concurrent = {
      requests: concurrentRequests,
      successful: successfulRequests,
      avgResponseTime: avgResponseTime,
      totalTime: totalTime
    };

    return true;
  }

  // Test 7: Security Validation
  async testSecurity() {
    console.log('\n🔒 === SECURITY VALIDATION ===');
    
    // Test without authentication
    const noAuthResult = await this.apiRequest('/api/emails/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prospectName: 'Test',
        prospectCompany: 'Test',
        prospectTitle: 'Test',
        linkedinUrl: 'https://linkedin.com/in/test',
        valueProposition: 'Test',
        emailType: 'professional'
      })
    });

    if (noAuthResult.status === 401) {
      this.log('SEC-001', 'Authentication properly enforced', 'PASS', {
        status: noAuthResult.status
      });
    } else {
      this.log('SEC-001', 'Authentication not enforced', 'FAIL', {
        status: noAuthResult.status,
        expectedStatus: 401
      });
    }

    // Test with invalid token
    const invalidTokenResult = await this.apiRequest('/api/emails/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer invalid-token-12345'
      },
      body: JSON.stringify({
        prospectName: 'Test',
        prospectCompany: 'Test',
        prospectTitle: 'Test',
        linkedinUrl: 'https://linkedin.com/in/test',
        valueProposition: 'Test',
        emailType: 'professional'
      })
    });

    if (invalidTokenResult.status === 401) {
      this.log('SEC-002', 'Invalid token properly rejected', 'PASS', {
        status: invalidTokenResult.status
      });
    } else {
      this.log('SEC-002', 'Invalid token not rejected', 'FAIL', {
        status: invalidTokenResult.status,
        expectedStatus: 401
      });
    }

    return true;
  }

  // Generate comprehensive report
  generateReport() {
    const { passed, failed, warnings } = this.results;
    const total = passed + failed;
    const passRate = total > 0 ? ((passed / total) * 100).toFixed(1) : 0;
    
    console.log('\n' + '='.repeat(80));
    console.log('🎯 COMPREHENSIVE DEBUG & TEST REPORT');
    console.log('='.repeat(80));
    console.log(`Total Tests: ${total}`);
    console.log(`Passed: ${passed}`);
    console.log(`Failed: ${failed}`);
    console.log(`Warnings: ${warnings}`);
    console.log(`Pass Rate: ${passRate}%`);
    
    if (this.results.performance.serverResponse) {
      console.log(`\n⚡ Performance Metrics:`);
      console.log(`- Server Response: ${this.results.performance.serverResponse}ms`);
      if (this.results.performance.concurrent) {
        console.log(`- Concurrent Processing: ${this.results.performance.concurrent.avgResponseTime.toFixed(0)}ms avg`);
        console.log(`- Concurrent Success Rate: ${((this.results.performance.concurrent.successful / this.results.performance.concurrent.requests) * 100).toFixed(1)}%`);
      }
    }

    if (this.results.errors.length > 0) {
      console.log(`\n❌ Critical Issues:`);
      this.results.errors.forEach(error => {
        console.log(`- ${error.testId}: ${error.description}`);
        if (error.details.error) {
          console.log(`  Error: ${error.details.error}`);
        }
      });
    }

    console.log(`\n📋 System Status:`);
    console.log(`- Authentication: ${this.sessionId ? '✅ Working' : '❌ Failed'}`);
    console.log(`- Email Generation: ${this.results.functionality.emailGeneration ? '✅ Working' : '❓ Unknown'}`);
    console.log(`- PayPal Integration: ⚠️  Development Mode (credentials needed)`);
    console.log(`- Analytics: ${this.results.functionality.analytics ? '✅ Working' : '❓ Unknown'}`);
    
    console.log(`\n🎯 Overall Assessment:`);
    if (failed === 0 && passed > 10) {
      console.log('✅ SYSTEM HEALTHY - All core functions working correctly');
    } else if (failed <= 2) {
      console.log('⚠️  SYSTEM STABLE - Minor issues detected');
    } else {
      console.log('❌ SYSTEM ISSUES - Multiple failures detected');
    }

    return {
      passRate: parseFloat(passRate),
      criticalFailures: failed,
      systemHealthy: failed === 0 && passed > 10
    };
  }

  // Main test runner
  async runAllTests() {
    console.log('🚀 Starting Comprehensive Debug & Test Suite\n');
    console.log('Testing against:', API_BASE);
    
    try {
      // System health check
      const healthOk = await this.testSystemHealth();
      if (!healthOk) {
        console.log('❌ System health check failed, aborting tests');
        return this.generateReport();
      }

      // Core functionality tests
      await this.testAuthenticationFlow();
      await this.testEmailGeneration();
      await this.testAnalyticsSystem();
      
      // Integration tests
      await this.testPayPalIntegration();
      
      // Performance & security
      await this.testPerformance();
      await this.testSecurity();
      
    } catch (error) {
      console.error('\n❌ Test suite encountered critical error:', error.message);
      this.log('CRITICAL', 'Test suite failure', 'FAIL', { error: error.message });
    }

    return this.generateReport();
  }
}

// Execute debug test suite
const debugSuite = new DebugTestSuite();
debugSuite.runAllTests().then(report => {
  console.log('\n🏁 Debug testing complete');
  process.exit(report.systemHealthy ? 0 : 1);
}).catch(error => {
  console.error('Debug suite error:', error);
  process.exit(1);
});
