# Deployment Guide

## Production Deployment Options

### Vercel (Recommended)
1. Connect GitHub repository to Vercel
2. Configure environment variables in Vercel dashboard
3. Set build command: `npm run build`
4. Set output directory: `dist`
5. Deploy automatically on push to main branch

### Railway
1. Connect repository to Railway
2. Add environment variables in Railway dashboard
3. Railway will auto-detect Node.js and deploy

### Replit Deployments
1. Use existing Replit environment
2. Click Deploy button in Replit interface
3. Configure custom domain if needed
4. Automatic scaling and SSL included

## Environment Variables

Required for production:
```
DATABASE_URL=postgresql://user:password@host:port/database
GOOGLE_GEMINI_API_KEY=your_gemini_api_key
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret
NODE_ENV=production
SESSION_SECRET=random_secure_string
```

## Database Setup

### PostgreSQL Requirements
- PostgreSQL 13+
- Connection pooling recommended
- SSL enabled for production

### Migration Commands
```bash
npm run db:push
```

## Production Checklist

### Security
- [ ] HTTPS enabled
- [ ] Environment variables secured
- [ ] Rate limiting configured
- [ ] Input validation active
- [ ] Session security enabled

### Performance
- [ ] Database indexes optimized
- [ ] Response caching implemented
- [ ] Static asset compression
- [ ] Health checks configured

### Monitoring
- [ ] Error tracking setup
- [ ] Performance monitoring
- [ ] Database monitoring
- [ ] Uptime monitoring

## Health Checks

The application provides health check endpoints:
- `GET /api/health` - Basic health status
- `GET /api/config` - Configuration verification

## Scaling Considerations

### Horizontal Scaling
- Stateless application design
- Session store externalization
- Database connection pooling

### Performance Optimization
- Response time < 200ms
- 99.9% uptime target
- Concurrent user support

## Troubleshooting

### Common Issues
1. Database connection failures
2. API key authentication errors
3. PayPal configuration issues
4. Rate limiting conflicts

### Debug Commands
```bash
node test-comprehensive-implementation.mjs
npm run build
npm run start
```

### Log Monitoring
- Application logs in console
- Database query logs
- API request/response logs
- Error stack traces