# Contributing to AI Cold Email Personalizer

Thank you for your interest in contributing to this project! This guide will help you get started.

## Development Setup

### Prerequisites
- Node.js 18+
- PostgreSQL database
- Google Gemini API key
- PayPal sandbox credentials

### Local Development
1. Fork and clone the repository
2. Install dependencies: `npm install`
3. Copy environment variables: `cp .env.example .env`
4. Configure your `.env` with valid API credentials
5. Setup database: `npm run db:push`
6. Start development server: `npm run dev`

## Testing

### Comprehensive Test Suite
Run all tests before submitting contributions:
```bash
node test-comprehensive-implementation.mjs
```

The test suite covers:
- Authentication and session management
- AI email generation functionality
- Payment processing integration
- Database operations
- Security validations
- Performance benchmarks

**Required**: All tests must pass (100% success rate) before PR submission.

### Manual Testing
1. Test user registration and login flows
2. Generate emails with different LinkedIn profiles
3. Verify payment processing works correctly
4. Check analytics dashboard functionality
5. Test rate limiting behavior

## Code Quality

### Standards
- TypeScript for type safety
- ESLint configuration compliance
- Consistent code formatting
- Comprehensive error handling
- Security best practices

### Database Changes
- Use Drizzle ORM for schema modifications
- Run `npm run db:push` to apply changes
- Never write raw SQL migrations
- Test database operations thoroughly

## Submission Process

### Pull Request Guidelines
1. Create feature branch from `main`
2. Make focused, atomic commits
3. Write descriptive commit messages
4. Ensure all tests pass
5. Update documentation if needed
6. Submit PR with detailed description

### Review Criteria
- Functionality works as expected
- Code follows project conventions
- Tests maintain 100% pass rate
- Security considerations addressed
- Performance impact evaluated

## Areas for Contribution

### High Priority
- Enhanced email template variations
- Additional LinkedIn data extraction
- Improved analytics dashboards
- Performance optimizations
- Security enhancements

### Medium Priority
- UI/UX improvements
- Additional payment providers
- Export functionality
- Email scheduling features
- A/B testing capabilities

### Documentation
- API documentation improvements
- Setup guide enhancements
- Troubleshooting guides
- Video tutorials
- Best practices documentation

## Getting Help

- Review existing issues and discussions
- Check the comprehensive test results
- Consult the README documentation
- Ask questions in GitHub issues

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help maintain code quality
- Support fellow contributors

Thank you for contributing to make this platform better!