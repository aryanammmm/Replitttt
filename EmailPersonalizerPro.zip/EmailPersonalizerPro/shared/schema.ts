import { pgTable, text, serial, integer, timestamp, boolean, jsonb, uuid, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with enhanced schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  company: text("company"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  isActive: boolean("is_active").default(true),
  creditsUsed: integer("credits_used").default(0),
  creditsLimit: integer("credits_limit").default(100),
  planType: varchar("plan_type", { length: 20 }).default("trial"), // trial, professional, enterprise
  trialEndsAt: timestamp("trial_ends_at"),
  stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
});

// Email generations table (combining generated emails with profile data)
export const emailGenerations = pgTable("email_generations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  linkedinUrl: text("linkedin_url").notNull(),
  profileData: jsonb("profile_data"), // Store LinkedIn profile information
  generatedEmails: jsonb("generated_emails"), // Store all 3 email variations
  createdAt: timestamp("created_at").defaultNow(),
});

// Usage analytics table (enhanced from usage logs)
export const usageAnalytics = pgTable("usage_analytics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: varchar("action", { length: 50 }).notNull(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Payments table for tracking transactions
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  paypalOrderId: varchar("paypal_order_id", { length: 255 }),
  amount: integer("amount").notNull(), // Amount in cents
  currency: varchar("currency", { length: 3 }).default("USD"),
  status: varchar("status", { length: 20 }).notNull(), // pending, completed, failed, refunded
  planType: varchar("plan_type", { length: 20 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Legacy tables for backward compatibility (will be migrated)
export const generatedEmails = pgTable("generated_emails", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  prospectName: text("prospect_name").notNull(),
  prospectCompany: text("prospect_company"),
  prospectTitle: text("prospect_title"),
  linkedinUrl: text("linkedin_url"),
  valueProposition: text("value_proposition"),
  emailType: text("email_type").default("professional"),
  subjectLine: text("subject_line").notNull(),
  emailBody: text("email_body").notNull(),
  personalizationScore: integer("personalization_score").default(8),
  createdAt: timestamp("created_at").defaultNow(),
});

export const usageLogs = pgTable("usage_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  actionType: text("action_type").notNull(),
  metadata: jsonb("metadata").default('{}'),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas for new tables
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmailGenerationSchema = createInsertSchema(emailGenerations).omit({
  id: true,
  createdAt: true,
});

export const insertUsageAnalyticsSchema = createInsertSchema(usageAnalytics).omit({
  id: true,
  createdAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

// Legacy insert schemas (for backward compatibility)
export const insertEmailSchema = createInsertSchema(generatedEmails).omit({
  id: true,
  createdAt: true,
});

export const insertUsageLogSchema = createInsertSchema(usageLogs).omit({
  id: true,
  createdAt: true,
});

// Types for new tables
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type EmailGeneration = typeof emailGenerations.$inferSelect;
export type InsertEmailGeneration = z.infer<typeof insertEmailGenerationSchema>;
export type UsageAnalytics = typeof usageAnalytics.$inferSelect;
export type InsertUsageAnalytics = z.infer<typeof insertUsageAnalyticsSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

// Legacy types (for backward compatibility)
export type GeneratedEmail = typeof generatedEmails.$inferSelect;
export type InsertGeneratedEmail = z.infer<typeof insertEmailSchema>;
export type UsageLog = typeof usageLogs.$inferSelect;
export type InsertUsageLog = z.infer<typeof insertUsageLogSchema>;
