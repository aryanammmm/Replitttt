
// Quick System Diagnostic for AI Cold Email Personalizer
import fetch from 'node-fetch';

const API_BASE = 'http://localhost:5000';

async function runDiagnostic() {
  console.log('🔍 AI Cold Email Personalizer - System Diagnostic\n');
  console.log('Target:', API_BASE);
  console.log('Time:', new Date().toISOString());
  console.log('='.repeat(60));

  // 1. Server Health
  try {
    const response = await fetch(API_BASE);
    console.log(`✅ Server Status: ${response.status} ${response.statusText}`);
  } catch (error) {
    console.log(`❌ Server Status: ${error.message}`);
    return;
  }

  // 2. Quick Auth Test
  try {
    const authResponse = await fetch(`${API_BASE}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: `diagnostic-${Date.now()}@test.com`,
        company: 'Diagnostic Corp'
      })
    });
    
    if (authResponse.ok) {
      const authData = await authResponse.json();
      console.log(`✅ Authentication: Working (User ID: ${authData.user?.id})`);
      
      // 3. Quick Email Generation Test
      const emailResponse = await fetch(`${API_BASE}/api/emails/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authData.sessionId}`
        },
        body: JSON.stringify({
          prospectName: 'Diagnostic User',
          prospectCompany: 'Test Corp',
          prospectTitle: 'Manager',
          linkedinUrl: 'https://linkedin.com/in/diagnostic-user',
          valueProposition: 'Diagnostic solution',
          emailType: 'professional'
        })
      });

      if (emailResponse.ok) {
        const emailData = await emailResponse.json();
        console.log(`✅ Email Generation: Working (${emailData.emails?.length || 0} emails generated)`);
      } else {
        console.log(`❌ Email Generation: Failed (${emailResponse.status})`);
      }

      // 4. Analytics Test
      const analyticsResponse = await fetch(`${API_BASE}/api/analytics/dashboard`, {
        headers: { 'Authorization': `Bearer ${authData.sessionId}` }
      });

      if (analyticsResponse.ok) {
        console.log(`✅ Analytics: Working`);
      } else {
        console.log(`❌ Analytics: Failed (${analyticsResponse.status})`);
      }

    } else {
      console.log(`❌ Authentication: Failed (${authResponse.status})`);
    }
  } catch (error) {
    console.log(`❌ API Tests: ${error.message}`);
  }

  // 5. PayPal Status
  try {
    const paypalResponse = await fetch(`${API_BASE}/paypal/setup`);
    if (paypalResponse.status === 401) {
      console.log(`⚠️  PayPal: Credentials needed (development mode)`);
    } else if (paypalResponse.ok) {
      console.log(`✅ PayPal: Configured`);
    } else {
      console.log(`❌ PayPal: Error (${paypalResponse.status})`);
    }
  } catch (error) {
    console.log(`❌ PayPal: ${error.message}`);
  }

  console.log('='.repeat(60));
  console.log('🏁 Diagnostic Complete');
}

runDiagnostic().catch(console.error);
