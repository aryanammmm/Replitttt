// Comprehensive test suite for AI Cold Email Personalizer
import { spawn } from 'child_process';
import fetch from 'node-fetch';

const API_BASE = 'http://localhost:5000';

// Test utilities
async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function testAPIEndpoint(endpoint, options = {}) {
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, options);
    const data = await response.json();
    return {
      success: response.ok,
      status: response.status,
      data: data
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

// Test 1: User Registration and Authentication
async function testUserAuth() {
  console.log('\n=== Testing User Authentication ===');
  
  const testUser = {
    email: `test-${Date.now()}@example.com`,
    company: 'Test Company Inc'
  };
  
  // Test user registration
  const registerResult = await testAPIEndpoint('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(testUser)
  });
  
  if (registerResult.success) {
    console.log('✓ User registration successful');
    const sessionId = registerResult.data.sessionId;
    
    // Test authenticated endpoint
    const authTest = await testAPIEndpoint('/api/auth/me', {
      headers: { 'Authorization': `Bearer ${sessionId}` }
    });
    
    if (authTest.success) {
      console.log('✓ Authentication system working');
      return { sessionId, user: authTest.data };
    } else {
      console.log('✗ Authentication verification failed');
      return null;
    }
  } else {
    console.log('✗ User registration failed:', registerResult.error || registerResult.data?.message);
    return null;
  }
}

// Test 2: Email Generation System
async function testEmailGeneration(sessionId) {
  console.log('\n=== Testing Email Generation ===');
  
  const testCases = [
    {
      name: 'Software Engineer',
      data: {
        prospectName: 'John Smith',
        prospectCompany: 'Tech Solutions Inc',
        prospectTitle: 'Senior Software Engineer',
        linkedinUrl: 'https://linkedin.com/in/john-smith-software-engineer',
        valueProposition: 'AI-powered development tools that reduce coding time by 40%',
        emailType: 'professional'
      }
    },
    {
      name: 'Marketing Director',
      data: {
        prospectName: 'Sarah Johnson',
        prospectCompany: 'GrowthCorp',
        prospectTitle: 'Marketing Director',
        linkedinUrl: 'https://linkedin.com/in/sarah-johnson-marketing-director',
        valueProposition: 'Marketing automation platform that increases lead conversion by 300%',
        emailType: 'conversational'
      }
    },
    {
      name: 'Finance Manager',
      data: {
        prospectName: 'David Kim',
        prospectCompany: 'Financial Solutions LLC',
        prospectTitle: 'Finance Manager',
        linkedinUrl: 'https://linkedin.com/in/david-kim-finance-manager',
        valueProposition: 'Cost reduction software that saves 25% on operational expenses',
        emailType: 'direct'
      }
    }
  ];
  
  let successCount = 0;
  
  for (const testCase of testCases) {
    console.log(`\nTesting ${testCase.name}...`);
    
    const result = await testAPIEndpoint('/api/emails/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionId}`
      },
      body: JSON.stringify(testCase.data)
    });
    
    if (result.success && result.data.emails) {
      console.log(`✓ Generated ${result.data.emails.length} email variations`);
      console.log(`  - Profile analysis: ${result.data.profileData ? 'Success' : 'Failed'}`);
      console.log(`  - Credits used: ${result.data.creditsUsed || 0}`);
      
      // Validate email quality
      const emails = result.data.emails;
      let qualityPassed = true;
      
      for (const email of emails) {
        if (!email.subjectLine || email.subjectLine.length < 5) {
          console.log(`  ✗ Invalid subject line for ${email.emailType}`);
          qualityPassed = false;
        }
        if (!email.emailBody || email.emailBody.length < 50) {
          console.log(`  ✗ Email body too short for ${email.emailType}`);
          qualityPassed = false;
        }
        if (email.personalizationScore < 7) {
          console.log(`  ⚠ Low personalization score (${email.personalizationScore}) for ${email.emailType}`);
        }
      }
      
      if (qualityPassed) {
        successCount++;
        console.log(`  ✓ Email quality validation passed`);
      }
      
    } else {
      console.log(`✗ Email generation failed:`, result.error || result.data?.message);
    }
    
    await delay(500); // Prevent rate limiting
  }
  
  console.log(`\nEmail Generation Summary: ${successCount}/${testCases.length} tests passed`);
  return successCount === testCases.length;
}

// Test 3: Analytics Dashboard
async function testAnalytics(sessionId) {
  console.log('\n=== Testing Analytics Dashboard ===');
  
  const result = await testAPIEndpoint('/api/analytics/dashboard', {
    headers: { 'Authorization': `Bearer ${sessionId}` }
  });
  
  if (result.success) {
    const analytics = result.data;
    
    // Validate analytics structure
    const requiredFields = ['overview', 'industryBreakdown', 'emailTypeStats', 'dailyUsage', 'insights'];
    let structureValid = true;
    
    for (const field of requiredFields) {
      if (!analytics[field]) {
        console.log(`✗ Missing analytics field: ${field}`);
        structureValid = false;
      }
    }
    
    if (structureValid) {
      console.log('✓ Analytics structure validation passed');
      console.log(`  - Total emails: ${analytics.overview.totalEmails}`);
      console.log(`  - Credits used: ${analytics.overview.creditsUsed}/${analytics.overview.creditsLimit}`);
      console.log(`  - Plan type: ${analytics.overview.planType}`);
      return true;
    } else {
      console.log('✗ Analytics structure validation failed');
      return false;
    }
  } else {
    console.log('✗ Analytics dashboard failed:', result.error || result.data?.message);
    return false;
  }
}

// Test 4: Email History Retrieval
async function testEmailHistory(sessionId) {
  console.log('\n=== Testing Email History ===');
  
  const result = await testAPIEndpoint('/api/emails', {
    headers: { 'Authorization': `Bearer ${sessionId}` }
  });
  
  if (result.success) {
    const emails = result.data.emails;
    console.log(`✓ Retrieved ${emails.length} emails from history`);
    
    if (emails.length > 0) {
      const latestEmail = emails[0];
      const requiredFields = ['id', 'prospectName', 'subjectLine', 'emailBody', 'createdAt'];
      
      let fieldsValid = true;
      for (const field of requiredFields) {
        if (!latestEmail[field]) {
          console.log(`✗ Missing email field: ${field}`);
          fieldsValid = false;
        }
      }
      
      if (fieldsValid) {
        console.log('✓ Email history structure validation passed');
        return true;
      } else {
        console.log('✗ Email history structure validation failed');
        return false;
      }
    } else {
      console.log('⚠ No emails in history (expected after testing)');
      return true;
    }
  } else {
    console.log('✗ Email history retrieval failed:', result.error || result.data?.message);
    return false;
  }
}

// Test 5: Error Handling
async function testErrorHandling() {
  console.log('\n=== Testing Error Handling ===');
  
  const errorTests = [
    {
      name: 'Unauthenticated request',
      test: () => testAPIEndpoint('/api/emails/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prospectName: 'Test' })
      }),
      expectStatus: 401
    },
    {
      name: 'Invalid email generation data',
      test: () => testAPIEndpoint('/api/emails/generate', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer invalid-token'
        },
        body: JSON.stringify({ invalidField: 'test' })
      }),
      expectStatus: 401
    }
  ];
  
  let errorTestsPassed = 0;
  
  for (const errorTest of errorTests) {
    console.log(`Testing ${errorTest.name}...`);
    const result = await errorTest.test();
    
    if (result.status === errorTest.expectStatus) {
      console.log(`✓ ${errorTest.name} handled correctly`);
      errorTestsPassed++;
    } else {
      console.log(`✗ ${errorTest.name} - Expected status ${errorTest.expectStatus}, got ${result.status}`);
    }
  }
  
  console.log(`Error Handling Summary: ${errorTestsPassed}/${errorTests.length} tests passed`);
  return errorTestsPassed === errorTests.length;
}

// Main test runner
async function runComprehensiveTests() {
  console.log('🚀 Starting Comprehensive Test Suite for AI Cold Email Personalizer\n');
  
  // Wait for server to be ready
  console.log('Waiting for server to be ready...');
  await delay(2000);
  
  let testResults = {
    auth: false,
    emailGeneration: false,
    analytics: false,
    emailHistory: false,
    errorHandling: false
  };
  
  try {
    // Test 1: Authentication
    const authResult = await testUserAuth();
    testResults.auth = !!authResult;
    
    if (authResult) {
      // Test 2: Email Generation
      testResults.emailGeneration = await testEmailGeneration(authResult.sessionId);
      
      // Test 3: Analytics
      testResults.analytics = await testAnalytics(authResult.sessionId);
      
      // Test 4: Email History
      testResults.emailHistory = await testEmailHistory(authResult.sessionId);
    }
    
    // Test 5: Error Handling
    testResults.errorHandling = await testErrorHandling();
    
  } catch (error) {
    console.error('\n❌ Test suite encountered an error:', error.message);
  }
  
  // Final Results
  console.log('\n' + '='.repeat(50));
  console.log('🏁 COMPREHENSIVE TEST RESULTS');
  console.log('='.repeat(50));
  
  const tests = [
    { name: 'User Authentication', result: testResults.auth },
    { name: 'Email Generation', result: testResults.emailGeneration },
    { name: 'Analytics Dashboard', result: testResults.analytics },
    { name: 'Email History', result: testResults.emailHistory },
    { name: 'Error Handling', result: testResults.errorHandling }
  ];
  
  let passedTests = 0;
  
  for (const test of tests) {
    const status = test.result ? '✅ PASS' : '❌ FAIL';
    console.log(`${status} - ${test.name}`);
    if (test.result) passedTests++;
  }
  
  console.log('='.repeat(50));
  console.log(`Final Score: ${passedTests}/${tests.length} tests passed`);
  
  if (passedTests === tests.length) {
    console.log('🎉 ALL TESTS PASSED - Application is fully functional!');
  } else {
    console.log('⚠️  Some tests failed - Review the issues above');
  }
  
  return passedTests === tests.length;
}

// Run the tests
runComprehensiveTests().then(success => {
  process.exit(success ? 0 : 1);
}).catch(error => {
  console.error('Test runner error:', error);
  process.exit(1);
});