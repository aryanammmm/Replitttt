# AI Cold Email Personalizer - Complete System Flowchart

## System Architecture Overview

```mermaid
graph TB
    A[User Visits Application] --> B{Authentication Status}
    
    B -->|Not Authenticated| C[Landing Page]
    B -->|Authenticated| D[Dashboard]
    
    C --> E[View Features]
    C --> F[View Pricing]
    C --> G[Register/Login]
    
    G --> H[Create Account]
    H --> I[Generate Session]
    I --> D
    
    D --> J[Email Generator]
    D --> K[Analytics Dashboard]
    D --> L[Email History]
    D --> M[Account Settings]
    
    J --> N[Input Prospect Data]
    N --> O[LinkedIn URL Analysis]
    O --> P{Profile Analysis}
    
    P -->|Success| Q[Enhanced Profile Data]
    P -->|Failure| R[Fallback Profile Data]
    
    Q --> S[AI Email Generation]
    R --> S
    
    S --> T[Generate 3 Variations]
    T --> U[Professional Email]
    T --> V[Conversational Email]
    T --> W[Direct Email]
    
    U --> X[Store in Database]
    V --> X
    W --> X
    
    X --> Y[Update Credits]
    Y --> Z[Display Results]
    
    K --> AA[Fetch Analytics Data]
    AA --> BB[Industry Breakdown]
    AA --> CC[Performance Metrics]
    AA --> DD[Usage Patterns]
    
    L --> EE[Fetch Email History]
    EE --> FF[Display Email List]
    FF --> GG[Copy Email Content]
    
    M --> HH[Upgrade Plan]
    HH --> II[PayPal Integration]
    II --> JJ[Process Payment]
    JJ --> KK[Update Subscription]
```

## Detailed User Journey Flow

### 1. Application Entry Point
```mermaid
graph LR
    A[User Access] --> B[App.tsx Router]
    B --> C{useAuth Hook}
    C -->|Loading| D[Loading Spinner]
    C -->|Not Authenticated| E[Landing Page]
    C -->|Authenticated| F[Dashboard]
```

### 2. Landing Page Flow
```mermaid
graph TB
    A[Landing Page] --> B[Hero Section]
    B --> C[Features Showcase]
    C --> D[Testimonials]
    D --> E[Pricing Section]
    E --> F[Call-to-Action]
    F --> G[Auth Modal]
    G --> H[User Registration]
    H --> I[Session Creation]
    I --> J[Redirect to Dashboard]
```

### 3. Email Generation Process
```mermaid
graph TB
    A[Email Generator Form] --> B[Input Validation]
    B -->|Valid| C[Submit Request]
    B -->|Invalid| D[Show Validation Errors]
    
    C --> E[Check Credit Limits]
    E -->|Sufficient| F[LinkedIn Profile Analysis]
    E -->|Exceeded| G[Credit Limit Error]
    
    F --> H[Free LinkedIn Service]
    H --> I{URL Parsing Success}
    
    I -->|Success| J[Extract Profile Data]
    I -->|Failure| K[Use Fallback Data]
    
    J --> L[Build Prospect Profile]
    K --> L
    
    L --> M[AI Personalization Engine]
    M --> N[Generate 3 Email Types]
    
    N --> O[Professional Template]
    N --> P[Conversational Template]
    N --> Q[Direct Template]
    
    O --> R[Store in Database]
    P --> R
    Q --> R
    
    R --> S[Update User Credits]
    S --> T[Create Usage Log]
    T --> U[Return Results]
```

### 4. Analytics Dashboard Flow
```mermaid
graph TB
    A[Analytics Page] --> B[Fetch User Data]
    B --> C[Get Email Generations]
    C --> D[Calculate Metrics]
    
    D --> E[Total Emails Count]
    D --> F[Last 30 Days Activity]
    D --> G[Credits Usage]
    D --> H[Industry Analysis]
    
    H --> I[Industry Breakdown Chart]
    E --> J[Overview Cards]
    F --> J
    G --> J
    
    D --> K[Email Type Performance]
    K --> L[Performance Charts]
    
    D --> M[Daily Usage Patterns]
    M --> N[Usage Timeline]
    
    D --> O[Generate Insights]
    O --> P[Most Active Day]
    O --> Q[Top Industry]
    O --> R[Best Performing Type]
```

### 5. PayPal Payment Flow
```mermaid
graph TB
    A[Upgrade Plan Button] --> B[Upgrade Modal]
    B --> C[Select Plan]
    C --> D[PayPal Button]
    
    D --> E[Load PayPal SDK]
    E --> F[Create Order]
    F --> G[PayPal Checkout]
    
    G --> H{Payment Status}
    H -->|Approved| I[Capture Order]
    H -->|Cancelled| J[Return to Modal]
    H -->|Error| K[Show Error]
    
    I --> L[Update User Plan]
    L --> M[Update Credits Limit]
    M --> N[Create Payment Record]
    N --> O[Success Confirmation]
```

## Database Schema Flow

### 6. Data Storage Architecture
```mermaid
graph TB
    A[User Registration] --> B[users Table]
    B --> C[User Profile Data]
    
    D[Email Generation] --> E[generated_emails Table]
    E --> F[Email Content Storage]
    
    D --> G[email_generations Table]
    G --> H[Profile & Analytics Data]
    
    I[User Actions] --> J[usage_logs Table]
    J --> K[Activity Tracking]
    
    L[Payments] --> M[payments Table]
    M --> N[Transaction Records]
    
    O[Analytics Queries] --> P[Aggregate Data]
    P --> Q[Dashboard Metrics]
```

## API Endpoint Flow

### 7. Backend API Architecture
```mermaid
graph TB
    A[Client Request] --> B[Express Router]
    B --> C[Session Middleware]
    C --> D{Authentication Required}
    
    D -->|Yes| E[requireAuth Middleware]
    D -->|No| F[Public Endpoint]
    
    E --> G{Valid Session}
    G -->|Valid| H[Process Request]
    G -->|Invalid| I[401 Unauthorized]
    
    H --> J[Database Operations]
    J --> K[Business Logic]
    K --> L[Response Formation]
    L --> M[Send Response]
    
    F --> N[Public Handler]
    N --> L
```

## Page Components Architecture

### 8. Frontend Component Hierarchy
```mermaid
graph TB
    A[App.tsx] --> B[Router Component]
    B --> C[Landing Page]
    B --> D[Dashboard]
    B --> E[Analytics Page]
    B --> F[Not Found Page]
    
    C --> G[Hero Section]
    C --> H[Features List]
    C --> I[Testimonials]
    C --> J[Pricing Section]
    C --> K[Auth Modal]
    
    D --> L[Email Generator]
    D --> M[Dashboard Stats]
    D --> N[Recent Emails]
    
    E --> O[Analytics Dashboard Component]
    O --> P[Overview Cards]
    O --> Q[Charts Components]
    O --> R[Insights Panel]
    
    L --> S[Form Components]
    L --> T[Results Display]
    L --> U[Email Variations]
```

## Error Handling Flow

### 9. Error Management System
```mermaid
graph TB
    A[User Action] --> B[Input Validation]
    B -->|Invalid| C[Client-Side Error]
    B -->|Valid| D[API Request]
    
    D --> E[Server Processing]
    E -->|Success| F[Return Data]
    E -->|Error| G[Server Error Handler]
    
    G --> H[Log Error]
    H --> I[Determine Error Type]
    
    I --> J[Validation Error - 400]
    I --> K[Auth Error - 401]
    I --> L[Credit Error - 403]
    I --> M[Server Error - 500]
    
    J --> N[Return Error Details]
    K --> N
    L --> N
    M --> N
    
    N --> O[Client Error Handler]
    O --> P[Display Toast Message]
    O --> Q[Update UI State]
    
    C --> R[Form Validation Display]
    R --> S[Highlight Invalid Fields]
```

## Security Flow

### 10. Security Implementation
```mermaid
graph TB
    A[User Request] --> B[HTTPS Enforcement]
    B --> C[Session Validation]
    
    C --> D[Session Store Check]
    D -->|Valid| E[User ID Extraction]
    D -->|Invalid| F[Reject Request]
    
    E --> G[Input Sanitization]
    G --> H[SQL Injection Prevention]
    H --> I[XSS Protection]
    
    I --> J[Rate Limiting Check]
    J -->|Within Limits| K[Process Request]
    J -->|Exceeded| L[Rate Limit Error]
    
    K --> M[Database Query]
    M --> N[Parameterized Queries]
    N --> O[Return Sanitized Data]
```