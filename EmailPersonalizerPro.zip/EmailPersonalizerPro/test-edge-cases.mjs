// Edge case and performance testing for AI Cold Email Personalizer
import fetch from 'node-fetch';

const API_BASE = 'http://localhost:5000';

async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function testAPIEndpoint(endpoint, options = {}) {
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, options);
    const data = await response.json();
    return {
      success: response.ok,
      status: response.status,
      data: data,
      responseTime: Date.now() - options.startTime
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

// Create test user for edge cases
async function setupTestUser() {
  const testUser = {
    email: `edge-test-${Date.now()}@example.com`,
    company: 'Edge Test Corp'
  };
  
  const result = await testAPIEndpoint('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(testUser),
    startTime: Date.now()
  });
  
  return result.success ? result.data.sessionId : null;
}

// Test 1: Input Validation Edge Cases
async function testInputValidation(sessionId) {
  console.log('\n=== Testing Input Validation Edge Cases ===');
  
  const edgeCases = [
    {
      name: 'Empty fields',
      data: {
        prospectName: '',
        prospectCompany: '',
        prospectTitle: '',
        linkedinUrl: '',
        valueProposition: '',
        emailType: 'professional'
      }
    },
    {
      name: 'Very long inputs',
      data: {
        prospectName: 'A'.repeat(1000),
        prospectCompany: 'B'.repeat(1000),
        prospectTitle: 'C'.repeat(1000),
        linkedinUrl: 'https://linkedin.com/in/' + 'x'.repeat(500),
        valueProposition: 'D'.repeat(2000),
        emailType: 'professional'
      }
    },
    {
      name: 'Special characters',
      data: {
        prospectName: 'João O\'Connor-Smith',
        prospectCompany: 'Tech & Co. (Zürich) Ltd.',
        prospectTitle: 'Sr. Vice-President of R&D',
        linkedinUrl: 'https://linkedin.com/in/joão-o-connor-smith',
        valueProposition: 'Solution that saves 50% costs & increases ROI by 200%',
        emailType: 'conversational'
      }
    },
    {
      name: 'Invalid LinkedIn URLs',
      data: {
        prospectName: 'Test User',
        prospectCompany: 'Test Corp',
        prospectTitle: 'Manager',
        linkedinUrl: 'not-a-valid-url',
        valueProposition: 'Great solution',
        emailType: 'direct'
      }
    },
    {
      name: 'Invalid email type',
      data: {
        prospectName: 'Test User',
        prospectCompany: 'Test Corp',
        prospectTitle: 'Manager',
        linkedinUrl: 'https://linkedin.com/in/test-user',
        valueProposition: 'Great solution',
        emailType: 'invalid-type'
      }
    }
  ];
  
  let validationTestsPassed = 0;
  
  for (const testCase of edgeCases) {
    console.log(`Testing ${testCase.name}...`);
    
    const result = await testAPIEndpoint('/api/emails/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionId}`
      },
      body: JSON.stringify(testCase.data),
      startTime: Date.now()
    });
    
    // System should handle edge cases gracefully
    if (result.success && result.data.emails) {
      console.log(`✓ ${testCase.name} - Generated emails successfully`);
      validationTestsPassed++;
    } else if (result.status === 400) {
      console.log(`✓ ${testCase.name} - Properly rejected invalid input`);
      validationTestsPassed++;
    } else {
      console.log(`✗ ${testCase.name} - Unexpected response:`, result.error || result.data?.message);
    }
    
    await delay(200);
  }
  
  console.log(`Input Validation Summary: ${validationTestsPassed}/${edgeCases.length} tests passed`);
  return validationTestsPassed >= Math.floor(edgeCases.length * 0.8); // 80% pass rate acceptable
}

// Test 2: Performance and Load Testing
async function testPerformance(sessionId) {
  console.log('\n=== Testing Performance and Load ===');
  
  const testData = {
    prospectName: 'Performance Test User',
    prospectCompany: 'Load Test Corp',
    prospectTitle: 'Performance Engineer',
    linkedinUrl: 'https://linkedin.com/in/performance-test-user',
    valueProposition: 'Performance optimization solution',
    emailType: 'professional'
  };
  
  // Single request performance
  console.log('Testing single request performance...');
  const startTime = Date.now();
  const singleResult = await testAPIEndpoint('/api/emails/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${sessionId}`
    },
    body: JSON.stringify(testData),
    startTime: startTime
  });
  
  if (singleResult.success) {
    console.log(`✓ Single request completed in ${singleResult.responseTime}ms`);
    
    if (singleResult.responseTime < 5000) {
      console.log('✓ Response time within acceptable limits (<5s)');
    } else {
      console.log('⚠ Response time slower than expected (>5s)');
    }
  } else {
    console.log('✗ Single request failed');
    return false;
  }
  
  // Concurrent requests test
  console.log('\nTesting concurrent requests...');
  const concurrentRequests = 3;
  const promises = [];
  
  for (let i = 0; i < concurrentRequests; i++) {
    const modifiedData = {
      ...testData,
      prospectName: `Concurrent User ${i + 1}`,
      linkedinUrl: `https://linkedin.com/in/concurrent-user-${i + 1}`
    };
    
    promises.push(
      testAPIEndpoint('/api/emails/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionId}`
        },
        body: JSON.stringify(modifiedData),
        startTime: Date.now()
      })
    );
  }
  
  const concurrentStartTime = Date.now();
  const results = await Promise.all(promises);
  const concurrentEndTime = Date.now();
  
  const successfulRequests = results.filter(r => r.success).length;
  console.log(`✓ ${successfulRequests}/${concurrentRequests} concurrent requests successful`);
  console.log(`Total concurrent processing time: ${concurrentEndTime - concurrentStartTime}ms`);
  
  return successfulRequests >= Math.floor(concurrentRequests * 0.8);
}

// Test 3: Memory and Resource Management
async function testResourceManagement(sessionId) {
  console.log('\n=== Testing Resource Management ===');
  
  // Test repeated requests to check for memory leaks
  console.log('Testing repeated requests for memory stability...');
  
  const testData = {
    prospectName: 'Memory Test User',
    prospectCompany: 'Resource Test Corp',
    prospectTitle: 'Memory Manager',
    linkedinUrl: 'https://linkedin.com/in/memory-test-user',
    valueProposition: 'Memory optimization solution',
    emailType: 'direct'
  };
  
  let successCount = 0;
  const totalRequests = 5;
  
  for (let i = 0; i < totalRequests; i++) {
    const result = await testAPIEndpoint('/api/emails/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionId}`
      },
      body: JSON.stringify({
        ...testData,
        prospectName: `Memory Test User ${i + 1}`
      }),
      startTime: Date.now()
    });
    
    if (result.success) {
      successCount++;
    }
    
    await delay(100);
  }
  
  console.log(`✓ ${successCount}/${totalRequests} repeated requests successful`);
  
  // Test analytics still working after load
  const analyticsResult = await testAPIEndpoint('/api/analytics/dashboard', {
    headers: { 'Authorization': `Bearer ${sessionId}` },
    startTime: Date.now()
  });
  
  if (analyticsResult.success) {
    console.log('✓ Analytics system stable after load testing');
    return true;
  } else {
    console.log('✗ Analytics system degraded after load testing');
    return false;
  }
}

// Test 4: Data Consistency and Integrity
async function testDataIntegrity(sessionId) {
  console.log('\n=== Testing Data Consistency and Integrity ===');
  
  // Generate emails and verify data consistency
  const testData = {
    prospectName: 'Integrity Test User',
    prospectCompany: 'Data Integrity Corp',
    prospectTitle: 'Data Analyst',
    linkedinUrl: 'https://linkedin.com/in/integrity-test-user',
    valueProposition: 'Data integrity solution',
    emailType: 'professional'
  };
  
  const generateResult = await testAPIEndpoint('/api/emails/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${sessionId}`
    },
    body: JSON.stringify(testData),
    startTime: Date.now()
  });
  
  if (!generateResult.success) {
    console.log('✗ Failed to generate test emails for integrity check');
    return false;
  }
  
  await delay(500);
  
  // Check if data appears in history
  const historyResult = await testAPIEndpoint('/api/emails', {
    headers: { 'Authorization': `Bearer ${sessionId}` },
    startTime: Date.now()
  });
  
  if (!historyResult.success) {
    console.log('✗ Failed to retrieve email history');
    return false;
  }
  
  // Check if generated email appears in history
  const generatedEmails = generateResult.data.emails;
  const historyEmails = historyResult.data.emails;
  
  let dataConsistent = true;
  
  for (const generatedEmail of generatedEmails) {
    const foundInHistory = historyEmails.some(email => 
      email.prospectName === generatedEmail.prospectName &&
      email.subjectLine === generatedEmail.subjectLine
    );
    
    if (!foundInHistory) {
      console.log(`✗ Generated email not found in history: ${generatedEmail.subjectLine}`);
      dataConsistent = false;
    }
  }
  
  if (dataConsistent) {
    console.log('✓ Data consistency verified - generated emails appear in history');
  }
  
  // Check analytics update
  const analyticsResult = await testAPIEndpoint('/api/analytics/dashboard', {
    headers: { 'Authorization': `Bearer ${sessionId}` },
    startTime: Date.now()
  });
  
  if (analyticsResult.success) {
    const analytics = analyticsResult.data;
    if (analytics.overview.totalEmails > 0 && analytics.overview.creditsUsed > 0) {
      console.log('✓ Analytics properly updated after email generation');
      return dataConsistent;
    } else {
      console.log('✗ Analytics not properly updated');
      return false;
    }
  } else {
    console.log('✗ Failed to retrieve analytics for integrity check');
    return false;
  }
}

// Test 5: Security and Authentication Edge Cases
async function testSecurityEdgeCases() {
  console.log('\n=== Testing Security and Authentication Edge Cases ===');
  
  const securityTests = [
    {
      name: 'Invalid session token format',
      auth: 'Bearer invalid-token-format',
      expectStatus: 401
    },
    {
      name: 'Empty authorization header',
      auth: '',
      expectStatus: 401
    },
    {
      name: 'SQL injection attempt in session',
      auth: "Bearer '; DROP TABLE users; --",
      expectStatus: 401
    },
    {
      name: 'Very long session token',
      auth: 'Bearer ' + 'x'.repeat(10000),
      expectStatus: 401
    }
  ];
  
  let securityTestsPassed = 0;
  
  for (const test of securityTests) {
    console.log(`Testing ${test.name}...`);
    
    const headers = { 'Content-Type': 'application/json' };
    if (test.auth) {
      headers['Authorization'] = test.auth;
    }
    
    const result = await testAPIEndpoint('/api/emails/generate', {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({
        prospectName: 'Test',
        prospectCompany: 'Test',
        prospectTitle: 'Test',
        linkedinUrl: 'https://linkedin.com/in/test',
        valueProposition: 'Test',
        emailType: 'professional'
      }),
      startTime: Date.now()
    });
    
    if (result.status === test.expectStatus) {
      console.log(`✓ ${test.name} - Security properly enforced`);
      securityTestsPassed++;
    } else {
      console.log(`✗ ${test.name} - Expected ${test.expectStatus}, got ${result.status}`);
    }
  }
  
  console.log(`Security Testing Summary: ${securityTestsPassed}/${securityTests.length} tests passed`);
  return securityTestsPassed === securityTests.length;
}

// Main edge case test runner
async function runEdgeCaseTests() {
  console.log('🔍 Starting Edge Case and Performance Testing\n');
  
  await delay(1000);
  
  const sessionId = await setupTestUser();
  if (!sessionId) {
    console.error('❌ Failed to setup test user for edge case testing');
    return false;
  }
  
  console.log('✓ Test user setup complete');
  
  const testResults = {
    inputValidation: false,
    performance: false,
    resourceManagement: false,
    dataIntegrity: false,
    security: false
  };
  
  try {
    testResults.inputValidation = await testInputValidation(sessionId);
    testResults.performance = await testPerformance(sessionId);
    testResults.resourceManagement = await testResourceManagement(sessionId);
    testResults.dataIntegrity = await testDataIntegrity(sessionId);
    testResults.security = await testSecurityEdgeCases();
    
  } catch (error) {
    console.error('\n❌ Edge case testing encountered an error:', error.message);
  }
  
  // Final Results
  console.log('\n' + '='.repeat(60));
  console.log('🧪 EDGE CASE AND PERFORMANCE TEST RESULTS');
  console.log('='.repeat(60));
  
  const tests = [
    { name: 'Input Validation Edge Cases', result: testResults.inputValidation },
    { name: 'Performance and Load Testing', result: testResults.performance },
    { name: 'Resource Management', result: testResults.resourceManagement },
    { name: 'Data Integrity', result: testResults.dataIntegrity },
    { name: 'Security Edge Cases', result: testResults.security }
  ];
  
  let passedTests = 0;
  
  for (const test of tests) {
    const status = test.result ? '✅ PASS' : '❌ FAIL';
    console.log(`${status} - ${test.name}`);
    if (test.result) passedTests++;
  }
  
  console.log('='.repeat(60));
  console.log(`Edge Case Testing Score: ${passedTests}/${tests.length} tests passed`);
  
  if (passedTests >= Math.floor(tests.length * 0.8)) {
    console.log('🎯 Edge case testing passed - Application handles edge cases well!');
    return true;
  } else {
    console.log('⚠️ Some edge case tests failed - Review robustness');
    return false;
  }
}

runEdgeCaseTests().then(success => {
  process.exit(success ? 0 : 1);
}).catch(error => {
  console.error('Edge case test runner error:', error);
  process.exit(1);
});